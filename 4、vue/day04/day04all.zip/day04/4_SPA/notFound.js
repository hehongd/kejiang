var notFound={
  template:`<h1 style="color:red">404:你迷路了~</h1>`
}