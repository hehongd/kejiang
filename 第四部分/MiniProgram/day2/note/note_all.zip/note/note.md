# 微信小程序 - `Unit02`

# 1.`WXSS`

## 1.1 基础

`WXSS`(`Weixin Style Sheets`)，是一套样式语言，用于描述`WXML`的组件样式。

`WXSS`具备`CSS`的大部分特性，但对`CSS`进行了扩展：

A. 尺寸单位 -- `rpx`

B.样式导入

## 1.2 尺寸单位

`rpx`(`Responsive Pixel`)，响应式像素，可以根据屏幕分辨率进行自适应。

规定：屏幕宽度为`750rpx`

| 设备           | `rpx`换算`px` (屏幕宽度/750) | `px`换算`rpx` (750/屏幕宽度) |
| -------------- | ---------------------------- | ---------------------------- |
| `iPhone5`      | `1rpx` = `0.42px`            | `1px = 2.34rpx`              |
| `iPhone6`      | `1rpx` = `0.5px`             | `1px = 2rpx`                 |
| `iPhone6 Plus` | `1rpx` = `0.552px`           | `1px = 1.81rpx`              |

> 开发微信小程序时设计师可以用 `iPhone`6 作为视觉稿的标准。

## 1.3 样式导入

# 2.组件

## · `<scroll-view>`组件

`<scroll-view>`组件用于实现滚动的视图容器，其语法结构是：

```html

<scroll-view 
	scroll-x="是否允许水平滚动"
    scroll-y="是否允许垂直滚动"
    enable-flex="是否启用flex布局"
    enhanced="是否启用增强特性"
    show-scrollbar="是否显示滚动条">
    ...
</scroll-view>

```

## · `<image>`组件

`<image>`组件为图片组件，支持`GIF`、`JPG`、`PNG`、`SVG`和`WEBP`等图像格式，其语法结构是：

```html

<image 
	src="图像的URL地址" 
    lazy-load="是否采用懒加载"
    show-menu-by-longpress="长按是否显示识别小程序码的菜单"
    mode="图像裁切及缩放模式">
</image>

```

> `<image>`组件的图像大小为`320x240`
>
> `mode`属性常用的值：
>
> `aspectFit`，缩放模式，保持横纵比，显示出长边
>
> `aspectFill`，缩放模式，保持横纵比，显示出短边
>
> `webp`格式是谷歌推荐使用的图像格式，其体积约为`JPG`文件的`2/3`。
>
> 小程序的组件中单标记必须使用`/>`结尾

## · `<swiper>`组件

`<swiper>`组件为轮播图组件，其语法结构是：

```html

<swiper
	autoplay="是否自动播放"
  	indicator-dots="是否显示指示标志"
	indicator-color="指示标志正常显示的颜色"
	indicator-active-color="提示标志被选定时的颜色"
	circular="是否采用衔接滑动"
	interval="自动切换的时间间隔"
	duration="切换的时长">
    <swiper-item>...</swiper-item>
    ...
</swiper>

```

## · `<text>`组件

`<text>`组件为文本组件，其语法结构是：

```html

<text 
	user-select="文本是否可选"
    decode="是否支持解码">
    ...
</text>

```

> `decode`可以解析的是：`&gt;`、`&lt;`、`&amp;`、`&apos;`、`&nbsp;`
>
> `&emsp;`指中文空格
>
> `&ensp;`指中文空格的一半

## · `<navigator>`组件

`<navigator>`组件是页面链接组件，其语法结构是：

```html

<navigator 
   url="当前小程序内的页面路径" 
   open-type="跳转方式"
   hover-class="按下去的WXSS样式类名称"
   hover-start-time="多久后出现点击状(50)"
   hover-stay-time="点击状保持的时长(600)"
   hover-stop-propagation="是否阻止冒泡">
    ...
</navigator>

```

> `open-type`包括：
>
> `navigate`，默认的跳转方式，可以跳转到非`tabBar`页面，称为保留跳转，可以带有`URL`参数
>
> `navigateBack`，返回上级页面，此时需要配合`delta`属性使用
>
> `switchTab`，可以跳转到`tabBar`页面，会导致关闭所有的非`tabBar`页面
>
> `redirect`，关闭当前页面，重向定向到非`tabBar`页面，可以带有`URL` 参数
>
> `reLaunch`，关闭所有页面跳转到指定页面，可以带有`URL`参数

## · `<input>`组件

`<input>`组件为输入框组件，其语法结构是：

```html

<input 
	type="输入框类型"
    placeholder="占位符内容"
    value="初始内容"
    password="是否为密码"
    maxlength="最大长度"
    focus="是否自动获取焦点"
    bindinput="输入时触发的函数名称"
    bindfocus="获得焦点时触发的函数名称"
    bindblur="失去焦点时触发的函数名称">
</input>



```

> 输入框类型包括：
>
> `text`，文本输入键盘 
>
> `number`，数字输入键盘
>
> `digit`，带有小数点的数字输入键盘 
>
> `idcard`，身份证号输入键盘
>
> 小程序中组件绑定的事件处理函数中严禁出现小括号！，示例代码如下：
>
> ```html
> 
> <input type="text" bindinput="inputEvent"/>
> 
> ```
>
> 事件处理函数需要书写于`page.js`页面，示例代码如下：
>
> ```javascript
> 
> Page({
> 	data:{
> 		//...
> 	},
>     inputEvent(){
>         //....
>     }
> })
> 
> ```
>
> 像`<input>`组件的`bindinput`、`bindfocus`及`bindblur`等事件属于组件的自定义事件，对于组件的自定义事件，如果要获取其相关信息的话，必须在事件处理函数中带有`event`参数，该参数代表事件对象，可以通过该对象的`detail`属性获取相关的信息，示例代码如下：
>
> ```javascript
> 
> 
> Page({
> 	data:{
> 		//...
> 	},
>     inputEvent(event){
>         console.log(event.detail.value);
>     }
> })
> 
> ```
>
> ------
>
> `Vue.js`的对比
>
> ```html
> 
> <template>
>     <div>
>         <button @click="handle">按钮</button>
>     </div>
> </template>
> <script>
>     export default{
>         methods:{
>             handle(){
>                 console.log('Hello');
>             }
>         }
>     }
> </script>
> 
> ```

## · `<radio-group>`组件

`<radio-group>`组件为单选框群组组件，其语法结构是：

```html

<radio-group bindchange="选定项发生改变时触发的函数名称">
    <radio value="值" checked="是否被选定" color="颜色">...</radio>
    ...
</radio-group>

```

## · `<checkbox-group>`组件

`<checkbox-group>`组件为复选框群组组件，其语法结构是：

```html

<checkbox-group bindchange="选定项发生改变时触发的函数名称">
    <checkbox value="值" checked="是否被选定" color="颜色">...</checkbox>
    ...
</checkbox-group>

```

## · `<switch>`组件

`<switch>`组件是开关组件，其语法结构是：

```html

<switch 
	checked="是否被选定"
    color="颜色"
    type="样式(switch|checkbox)"
    bindchange="选定项发生改变时触发的函数名称">
    ...
</switch>



```

