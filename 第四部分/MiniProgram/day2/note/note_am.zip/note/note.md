# 微信小程序 - `Unit02`

# 1.`WXSS`

## 1.1 基础

`WXSS`(`Weixin Style Sheets`)，是一套样式语言，用于描述`WXML`的组件样式。

`WXSS`具备`CSS`的大部分特性，但对`CSS`进行了扩展：

A. 尺寸单位 -- `rpx`

B.样式导入

## 1.2 尺寸单位

`rpx`(`Responsive Pixel`)，响应式像素，可以根据屏幕分辨率进行自适应。

规定：屏幕宽度为`750rpx`

| 设备           | `rpx`换算`px` (屏幕宽度/750) | `px`换算`rpx` (750/屏幕宽度) |
| :------------- | :--------------------------- | :--------------------------- |
| `iPhone5`      | `1rpx` = `0.42px`            | `1px = 2.34rpx`              |
| `iPhone6`      | `1rpx` = `0.5px`             | `1px = 2rpx`                 |
| `iPhone6 Plus` | `1rpx` = `0.552px`           | `1px = 1.81rpx`              |

> 开发微信小程序时设计师可以用 `iPhone`6 作为视觉稿的标准。

## 1.3 样式导入

# 2.组件

## · `<image>`组件

`<image>`组件为图片组件，支持`GIF`、`JPG`、`PNG`、`SVG`和`WEBP`等图像格式，其语法结构是：

```html

<image 
	src="图像的URL地址" 
    lazy-load="是否采用懒加载"
    show-menu-by-longpress="长按是否显示识别小程序码的菜单"
    mode="图像裁切及缩放模式">
</image>

```

> `<image>`组件的图像大小为`320x240`
>
> `mode`属性常用的值：
>
> `aspectFit`，缩放模式，保持横纵比，显示出长边
>
> `aspectFill`，缩放模式，保持横纵比，显示出短边
>
> `webp`格式是谷歌推荐使用的图像格式，其体积约为`JPG`文件的`2/3`。
>
> 小程序的组件中单标记必须使用`/>`结尾

## · `<swiper>`组件

`<swiper>`组件为轮播图组件，其语法结构是：

```html

<swiper
	autoplay="是否自动播放"
  	indicator-dots="是否显示指示标志"
	indicator-color="指示标志正常显示的颜色"
	indicator-active-color="提示标志被选定时的颜色"
	circular="是否采用衔接滑动"
	interval="自动切换的时间间隔"
	duration="切换的时长">
    <swiper-item>...</swiper-item>
    ...
</swiper>

```

## · `<text>`组件

`<text>`组件为文本组件，其语法结构是：

```html

<text 
	user-select="文本是否可选"
    decode="是否支持解码">
    ...
</text>

```

