import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
})
export class Myc01Component implements OnInit {
  // 声明但是未赋值: 默认值是 undefined
  res: Result; //声明类型 html中才会有对应的提示

  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    // post请求的发送
    // 请求发送有两种方式 具体与服务器有关: 此处的接口服务器做过处理 兼容post 和 get 两种方式
    let url = 'http://101.96.128.94:9999/data/product/list.php';
    let body = 'pno=1';

    // 有些post请求可能要设定header, 默认有一个 content-type 可能需要设置
    let options = {
      headers: new HttpHeaders({
        // 因为默认值就是此设置, 所以options 写不写没有影响: 这里只是一个演示, 如何设置header
        'content-type': 'application/x-www-form-urlencoded',
      }),
    };

    // post请求主要指的是参数的传递方式不同.  post需要把 url?参数 的格式拆开
    // post的参数3: options 是可选的, 具体写不写要看服务器对接口的设定!
    this.http.post(url, body, options).subscribe((res: Result) => {
      console.log(res);

      this.res = res;
    });
  }

  getData() {
    let url = 'http://101.96.128.94:9999/data/product/list.php?pno=1';
    this.http.get(url).subscribe((res: Result) => {
      console.log(res);
      // 声明属性来保存请求下来的返回值:  因为返回值res是局部变量, 不能全局使用!
      this.res = res;
    });
  }
}

// 自定义返回值的数据类型: 为了vscode在html中给代码提示!
// 类 和 interface 是同级别, 不能包含!
// 类的封装: 封装变量和函数
interface Data {
  // 程序员大法: 复制 粘贴 改一改...
  is_onsale: string;
  lid: string;
  pic: string;
  price: string;
  sold_count: string;
  title: string;
}

interface Result {
  data: Data[];
  pageCount: number;
  pageSize: number;
  pno: number;
  recordCount: number;
}

/**
 * undefined 和 null 的差别?
 *
 * 此处两个场景:
 * 场景1: 然然在 23岁之前 没有过女朋友
 * 场景2: 然然在 24岁的时候 和女朋友分手了
 *
 * 请问 场景1  然然的女友 == undefined
 *     场景2   然然的女友 == null
 */
