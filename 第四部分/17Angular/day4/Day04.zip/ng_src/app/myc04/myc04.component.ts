import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css'],
})
export class Myc04Component implements OnInit {
  name = '我是myc04';
  age = 18;

  show() {
    alert(123);
  }

  constructor() {}

  ngOnInit(): void {}
}
