import { Component, ViewChild } from '@angular/core';
import { Myc04Component } from './myc04/myc04.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // @ViewChild('m4'): 代表 查找到 #m4 的元素
  // mm4 是自定义变量, 名字随意; 会自动关联到查找到的元素
  @ViewChild('m4') mm4: Myc04Component;

  changeM4() {
    console.log(this.mm4);

    // 12行 书写了类型声明, 此处才能有代码提示!
    this.mm4.name = '哈哈哈';
    this.mm4.show();
  }

  title = 'ngpro';

  // 1.父准备一个方法, 给子
  // msg是参数, 是子元素传递的信息
  showMsg(msg) {
    console.log(msg);
  }
}
