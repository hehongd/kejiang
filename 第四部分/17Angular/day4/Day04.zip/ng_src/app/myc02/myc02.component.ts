import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
export class Myc02Component implements OnInit {
  // 固定写法: 标注接收传递的属性
  // input: 输入
  @Input() title: string;
  @Input() name: string;
  @Input() age: number;
  @Input() hobby: string[];
  // any是偷懒写法, 不会报错 但是也没代码提示!
  // @Input() boss: any;
  @Input() boss: Boss;

  constructor() {}

  ngOnInit(): void {}
}

// 自定义类型必须主动声明 才能有代码提示
interface Boss {
  name: string;
  age: number;
}
