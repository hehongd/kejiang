import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// 1.引入
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { Work01Component } from './work01/work01.component';
import { Myc01Component } from './myc01/myc01.component';
import { Myc02Component } from './myc02/myc02.component';
import { Myc03Component } from './myc03/myc03.component';
import { Myc04Component } from './myc04/myc04.component';

@NgModule({
  declarations: [AppComponent, Work01Component, Myc01Component, Myc02Component, Myc03Component, Myc04Component],
  // 2.注入
  imports: [BrowserModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
