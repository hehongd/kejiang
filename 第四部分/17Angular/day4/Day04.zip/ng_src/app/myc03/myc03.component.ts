import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-myc03',
  templateUrl: './myc03.component.html',
  styleUrls: ['./myc03.component.css'],
})
export class Myc03Component implements OnInit {
  // output: 输出
  // EventEmitter(): 事件触发器; 用于保存外部传入的函数
  @Output() doMsg = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}
}
