import { Component, OnInit } from '@angular/core';
// * 引入http服务
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-work01',
  templateUrl: './work01.component.html',
  styleUrls: ['./work01.component.css'],
})
export class Work01Component implements OnInit {
  // 构造方法 public http: HttpCliet 是语法糖: 会自动生成下方的http属性
  // http: HttpClient;

  // 依赖注入机制:
  // constructor 被称为构造方法: 构造方法的参数 在类实例化时 必须传递才可以!  -- 来自于面向对象: 东哥
  // 依赖: 声明依赖 -- 构造方法中的参数 必须声明类型  变量名:类型名
  // 注入: 系统在实例化当前组件时, 就可以根据类型自动提供对应类型的对象
  constructor(public http: HttpClient) {}

  res: Res; //设定变量类型, vscode才能够给出对应的提示

  // 生命周期: 相当于 vue 的 mounted.  挂载时
  ngOnInit(): void {
    // this.http : 代表当前对象中的http成员属性
    let url = 'https://api.apiopen.top/getWangYiNews';

    // subscribe(回调方法): 订阅请求的返回值.
    this.http.get(url).subscribe((res: Res) => {
      console.log(res);
      // res: 局部变量, 只能在当前{}中使用
      // this.res: 成员属性, 必须提前声明才能使用; 特点: 可以全局通用, 在html中使用!
      // 相当于vue 中的 data 属性中的值!
      this.res = res;
    });
  }
}

// 高质量的代码, 需要前端书写时, 能够有代码提示; 则需要定制数据类型
interface Result {
  image: string;
  passtime: string;
  title: string;
  path: string;
}

// 类型名是自定义的, 你写Abc都可以..但是最好有含义!
interface Res {
  code: number;
  message: string;
  result: Result[]; //数组类型 中的元素 都是 Result类型
}
