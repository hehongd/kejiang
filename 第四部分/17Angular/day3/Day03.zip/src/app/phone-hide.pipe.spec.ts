import { PhoneHidePipe } from './phone-hide.pipe';

describe('PhoneHidePipe', () => {
  it('create an instance', () => {
    const pipe = new PhoneHidePipe();
    expect(pipe).toBeTruthy();
  });
});
