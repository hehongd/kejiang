import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'phoneHide',
})
export class PhoneHidePipe implements PipeTransform {
  // <p>{{ "18877889898" | phoneHide }}</p>

  transform(value: string) {
    // 小测试: 希望把手机号 中间4位 和 后4位 换位置
    // 18877779999 -> 18899997777
    // return value.replace(/(\d{3})(\d{4})(\d{4})/, '$1$3$2');

    // 18877889898  -> 188****9898
    // 思路: 截取 前3位 和 后4位, 重新拼接, 中间写 ****
    // 东哥: 正则表达式!
    // \d 代表数字   {n}代表n个   ()捕获组
    return value.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
    //                    第1个小括号   第2个小括号
    // $1 代表第1个小括号捕捉的内容
  }
}
