import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work01',
  templateUrl: './work01.component.html',
  styleUrls: ['./work01.component.css'],
})
export class Work01Component implements OnInit {
  items = ['吃饭', '睡觉', '打亮亮'];

  todo = '';

  doAdd() {
    this.items.push(this.todo);

    // 双向数据绑定:
    // 方向1: 数据变 UI变  -- 响应式编程!
    // 响应式: UI 会响应 数据的变化, 联动!
    this.todo = '';
  }

  constructor() {}

  ngOnInit(): void {}
}
