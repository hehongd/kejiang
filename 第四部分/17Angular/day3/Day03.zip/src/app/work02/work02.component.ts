import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work02',
  templateUrl: './work02.component.html',
  styleUrls: ['./work02.component.css'],
})
export class Work02Component implements OnInit {
  images = ['01.jpg', '02.jpg', '03.jpg', '04.jpg', '05.jpg'];

  // 变量: 变化的量
  // current page ->curP
  curP = 0; //当前序号

  constructor() {}

  // 生命周期, 类似于 mounted  挂载时
  ngOnInit(): void {
    setInterval(() => {
      this.next();
    }, 2000);
  }

  next() {
    this.curP++;
    // if写法的 语法糖: {}中只有一行代码, 则{}可以省略!
    // 例如: 数组有5个元素, 则序号是 0 1 2 3 4, 即最大序号是4
    // 如果 序号+1之后的值 是5 就说明超出限制, 则变为0
    if (this.curP == this.images.length) this.curP = 0;
  }

  prev() {
    this.curP--;
    // 最大序号 = 长度-1
    if (this.curP == -1) this.curP = this.images.length - 1;
  }
}
