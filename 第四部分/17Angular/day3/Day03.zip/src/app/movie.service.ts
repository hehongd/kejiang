import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MovieService {
  movies = [
    '阿凡达',
    '阿甘正传',
    '复仇者联盟',
    '林中小屋',
    '我是传奇',
    '僵尸世界大战',
  ];

  constructor() {}
}
