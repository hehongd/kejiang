import { Component, OnInit } from '@angular/core';
// 1.引入网络服务
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-myc06',
  templateUrl: './myc06.component.html',
  styleUrls: ['./myc06.component.css'],
})
export class Myc06Component implements OnInit {
  res: any; //只有成员变量才能 在html中使用

  // 2.声明依赖
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    //免费接口地址: https://api.apiopen.top/api.html

    //发送get请求
    let url = 'https://api.apiopen.top/getImages';
    // axios.get().then().catch()
    // 此处用 subscribe(订阅) 代替 then(然后)
    this.http.get(url).subscribe((res) => {
      console.log(res);
      this.res = res; //保存返回值到 成员变量中, 才能在html中使用
    });
  }
}
