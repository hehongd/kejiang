// 1. 引入
import { MovieService } from './../movie.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
export class Myc02Component implements OnInit {
  ms: MovieService;

  // 2. 使用
  // 声明依赖: 当前组件初始化的必备条件: 传入一个 MovieService 类型的值
  // 注入: 当系统初始化当前组件时, 就会受到依赖注入机制的影响, 必须传入一个 MovieService 类型的值
  // 使用时: 我们负责声明依赖, 系统负责自动注入操作!

  // 系统隐式完成:
  // let ms = new MovieService()
  // new Myc02Component(ms)

  // 变量名是你自己起的, MovieService 所以老师简写成 ms
  constructor(ms: MovieService) {
    this.ms = ms;
  }

  ngOnInit(): void {}
}
