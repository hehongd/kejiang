import { NamesService } from './../names.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc05',
  templateUrl: './myc05.component.html',
  styleUrls: ['./myc05.component.css'],
})
export class Myc05Component implements OnInit {
  // 服务依赖注入的语法糖
  // 语法糖: 某些功能实现的代码是固定的, 所以为了偷懒, 使用一些快捷写法 来代替固定的代码.
  // 糖: 外国人喜欢吃甜食, 认为甜是幸福的味道..  利用语法偷懒也很幸福
  // 例如:
  // if (xxx) { return xxx; }     ->  if (xxx) return xxx;
  // () => { return xxx; }   -> () => xxx;
  //
  // let obj = {name:'东东', age: 18};
  // 写法1: let name=obj.name; let age=obj.age;
  // 语法糖: let {name, age} = obj;
  constructor(public ns: NamesService) {}
  // 固定的简化写法:
  // 权限词 变量名: 注入的类型名
  // 权限词在此处随意写, public protected private 都不影响.  因为此变量在类内使用,无差别

  ngOnInit(): void {
    // this.
  }
}
