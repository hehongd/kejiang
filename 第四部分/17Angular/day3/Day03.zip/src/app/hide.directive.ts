import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appHide]',
})
export class HideDirective {
  constructor(e: ElementRef) {
    console.log(e);
    // 通过看后台打印, 可以看到能够操作的属性
    e.nativeElement.style.backgroundColor = 'red';
    e.nativeElement.style.display = 'none';
  }
}
