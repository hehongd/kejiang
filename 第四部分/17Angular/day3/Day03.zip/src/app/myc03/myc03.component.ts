import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-myc03',
  templateUrl: './myc03.component.html',
  styleUrls: ['./myc03.component.css'],
})
export class Myc03Component implements OnInit {
  abc: MovieService; //成员属性 保存外部传入的值

  // 变量名是 自定义的, 随便起, 但是最好有含义
  constructor(abc: MovieService) {
    this.abc = abc;
  }

  ngOnInit(): void {}
}
