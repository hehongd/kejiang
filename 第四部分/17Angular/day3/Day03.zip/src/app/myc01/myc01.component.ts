import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
})
export class Myc01Component implements OnInit {
  now = new Date().toLocaleTimeString();

  // 明天看一看东哥的面向对象
  // 构造方法: new 类(); 时自动触发
  constructor() {
    // 1. 刚怀孕
    console.log('constructor: 组件对象生成时 第一时间触发');
  }

  ngOnInit(): void {
    // 2. 开始生长
    console.log('ngOnInit: 组件中的数据开始初始化');

    setInterval(() => {
      this.now = new Date().toLocaleTimeString();
    }, 1000);
  }

  // 数据变化  UI变化
  ngAfterContentInit(): void {
    console.log('ngAfterContentInit: 组件内容中的数据开始初始化时');
  }

  ngAfterContentChecked(): void {
    console.log('ngAfterContentChecked: 组件内容中的数据变化时');
  }

  ngAfterViewInit(): void {
    console.log('ngAfterViewInit: UI视图初始化');
  }

  ngAfterViewChecked(): void {
    console.log('ngAfterViewChecked: UI视图变化时');
  }

  // 销毁
  ngOnDestroy(): void {
    //组件销毁时
    console.log('ngOnDestroy: 组件销毁时');
  }
}
