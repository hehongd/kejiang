import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work03',
  templateUrl: './work03.component.html',
  styleUrls: ['./work03.component.css']
})
export class Work03Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
