import { NamesService } from './../names.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css'],
})
export class Myc04Component implements OnInit {
  ns: NamesService; //此处类型声明是为了使用时有代码提示!

  // 服务使用通过依赖注入机制来获取 实例对象
  // NamesService -> ns
  // ns:类型;  系统全靠这个类型 来判断应该提供什么类型的对象
  constructor(ns: NamesService) {
    // ns 是局部变量, 只能在当前{}中用
    // 跨方法使用, 必须是 成员属性
    this.ns = ns;
  }

  ngOnInit(): void {}
}
