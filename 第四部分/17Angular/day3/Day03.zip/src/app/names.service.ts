import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class NamesService {
  names = ['亮亮', '然然', '东东'];

  constructor() {}
}
