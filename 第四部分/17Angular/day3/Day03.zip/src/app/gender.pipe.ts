import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender',
})
export class GenderPipe implements PipeTransform {
  // <p>{{ 0 | gender }}</p>
  // <p>{{ 1 | gender: "en" }}</p>

  // 语言 language -> lang
  // 参数2: 可以传 也可以不传, 则必须拥有默认值来应对不传递的情况
  transform(value: number, lang = 'zh') {
    if (lang == 'zh') {
      if (value == 0) return '女';
      if (value == 1) return '男';
    }
    // let arr = ['Women', 'Man'];
    // arr[value]   value是0或1  即  arr[0] 或 arr[1]
    // 数组[下标]
    if (lang == 'en') return ['Women', 'Man'][value];
  }
}
