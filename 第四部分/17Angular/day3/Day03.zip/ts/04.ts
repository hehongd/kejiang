/**
 * 访问权限词
 *
 * public  : 公开的 -- 类外 类内 子类
 * protected : 保护的 -- 类内 子类
 * private : 私有的 -- 类内
 */

class Demo {
  // 公开的
  public paper = "渣渣坤的手纸";
  // 保护的
  protected money = "渣渣坤的钱";
  // 私有的
  private secret = "年轻时犯过的错误!";

  show() {
    console.log(this.money);
  }
}

// 面向对象三大特征: 封装,继承,多态
class Son extends Demo {
  show() {
    this.paper;
    this.money;
    this.secret;
  }
}

let d = new Demo();
d.paper;

// 类外无法读取保护属性
// d.money;
