// 静态类型的声明

class Demo {
  name: string;
  age: number; //浮点+整型

  married: boolean;

  abc: any; //任意类型

  // 数组:  []代表数组   string代表数组中的元素都是string类型
  names: string[];
  // 等价上方写法, 但是略长, 不常用
  emps: Array<string>;
  /**
   * 变量名:类型名 = 值;
   */

  boss: object;
}

let d = new Demo();

d.boss = { name: "华华" };
d.boss = 123;

d.names = ["mike", "lucy", true, 123];

d.age = 123;
d.age = 123.44;
// d.age = "xx";

d.married = true;
d.married = false;

d.abc = 123;
d.abc = true;
