// ts 文件的最基本特征:  静态类型
// 特点: 代码不需要运行, vscode 就可以通过程序员 给的提示 去分析代码 并提供 报错 or 代码提示
// 变量:类型名    这就是类型声明
// 有了声明以后, vscode 就可以帮你分析代码
function show(name) {
  // name. 会出现代码提示:  vscode自动分析变量类型并给出提示!
  return name.toUpperCase();
}
show("dongdong");
// 报错提示: vscode会自动分析 类型是否匹配.  提前报错, 扼杀在萌芽里!
show(123);
// 编译命令:  tsc 文件名.ts
// 例如 tsc 01.ts
