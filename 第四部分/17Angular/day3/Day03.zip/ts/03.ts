// 自定义的对象类型

// 此处有一个数据类型

let emp = {
  name: "亮亮",
  age: 18,
  phone: "18877894455",
};
// 此对象类型含有3个属性名

/**
 * function 声明函数
 * class 声明类
 * interface 声明自定义对象类型
 */

interface Emp {
  name: string;
  age: number;
  phone: string;
}

// 如果有一个数组, 要求数组中的元素 必须是 含有指定属性结构的对象, 例如
let emps: Emp[]; //数组中的元素都是 Emp 类型的

emps = [
  { name: "东东", age: 12, phone: "17878889999" },
  { name: "亮亮", age: 12, phone: "17878889999" },
  { name: "然然", age: true },
];
