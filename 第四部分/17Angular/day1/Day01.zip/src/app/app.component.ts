import { Component } from '@angular/core';

/**
 * 之前学习的原生html中,  主文件是html 然后在html中引入了 js 和 css 文件, 最终显示出来
 *
 * angular 简称ng
 * 在ng中, 加载的主文件是ts文件, 引入了 html 和 css
 */

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'ngpro';
}
