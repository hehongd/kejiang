import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc06',
  templateUrl: './myc06.component.html',
  styleUrls: ['./myc06.component.css'],
})
export class Myc06Component implements OnInit {
  title = '我是小新老师';

  // 百度图片  必应图片 找一张网图地址
  // 右键网页中的图片, 复制图像地址 即可
  logo = 'https://www.baidu.com/img/flexible/logo/pc/result.png';

  html = '<h1>我是HTML代码</h1>';

  // 双向数据绑定
  // 方向1: ts -> html
  // 方向2: html -> ts  ??
  word = '默认123';

  constructor() {}

  ngOnInit(): void {}
}
