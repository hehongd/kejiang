import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css'],
})
export class Myc04Component implements OnInit {
  //面向对象的写法:  属性名=值;
  name = 'dongdong';
  age = 18;
  married = true;

  names = ['亮亮', '东东', '然然'];

  leader = {
    name: '文华',
    age: 33,
  };

  constructor() {}

  ngOnInit(): void {}
}
