// ES6 导出与导入

// 导出
// 可以导出多个
export const abc = 123;

// 一个文件只能最多导出一个default 方式
export default {
  name: "东东",
};

// 导入的时候:
import { abc } from "./demo.js";
import { launcher } from "karma";

// export default 方式 没有指定名称
// import xxx from "./demo.js";

// 面向对象写法
class Demo {
  name = "东东";

  show() {
    let name = "亮亮";

    alert(name); //亮亮
    alert(this.name); //东东

    // this的本质就是一个标识, 代表后方的内容是类中的属性
  }
}

// 区别于对象
let obj = {
  name: "东东",
};
