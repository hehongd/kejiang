// ts文件 负担合并任务: 把html和css引入

// 快捷 ng-component
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
// 注意 ES6导出写法 ,  default 和 非default方式的差异:  详见东哥笔记!
export class Myc02Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
