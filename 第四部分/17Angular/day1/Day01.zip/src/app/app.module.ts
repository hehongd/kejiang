import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// 引入Forms模块
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
// 1. 引入组件
import { Myc01Component } from './myc01/myc01.component';
import { Myc02Component } from './myc02/myc02.component';
import { Myc03Component } from './myc03/myc03.component';
import { Myc04Component } from './myc04/myc04.component';
import { Myc05Component } from './myc05/myc05.component';
import { Myc06Component } from './myc06/myc06.component';
import { Myc07Component } from './myc07/myc07.component';

// 当配置文件发生修改的时候, 往往需要重启服务器才能正常使用
// 在cmd中; 按两次 ctrl+C, 然后输入启动命令:
// ng serve --open     作者怕大家写错, 有简写格式: ng s -o
// 服务器不能多开, 同一个端口只能用一次.  重复开启会出现端口占用报错!!!
@NgModule({
  // 2. 注册组件
  declarations: [
    AppComponent,
    Myc01Component,
    Myc02Component,
    Myc03Component,
    Myc04Component,
    Myc05Component,
    Myc06Component,
    Myc07Component,
  ],
  // 注入Forms模块: 修改配置文件,特别是注入模块 必须重启服务器!!
  // 即:cmd中 按两次 ctrl+c  然后 ng s -o
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
