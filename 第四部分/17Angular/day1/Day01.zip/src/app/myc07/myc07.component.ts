import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc07',
  templateUrl: './myc07.component.html',
  styleUrls: ['./myc07.component.css'],
})
export class Myc07Component implements OnInit {
  // 变量: 代码运行期间可以变化的量
  num = 1;

  doAdd() {
    this.num++;
  }

  constructor() {}

  ngOnInit(): void {}
}
