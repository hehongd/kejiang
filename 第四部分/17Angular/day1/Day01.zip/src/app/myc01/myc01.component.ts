// 之前安装了angular插件

// ng-component  会有提示, 回车选择 自动生成!
// 生成的基础模板, 需要自己改造:
// 文件名结构:  name.component.xxx
// 把 name 替换到生成的模板代码中, 共4个位置
import { Component, OnInit } from '@angular/core';

@Component({
  // 按alt键 然后左键选择  就是多光标.  按ESC退出此模式
  selector: 'app-myc01', //组件名, 使用时 <app-myc01></app-myc01>
  templateUrl: './myc01.component.html',
  // 默认是 .scss后缀,  此处修改为css
  styleUrls: ['./myc01.component.css'],
})
// 晚上时间 最好是 看一下 东哥的面向对象部分
// 类名必须大驼峰, 即首字母大写
export class Myc01Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
