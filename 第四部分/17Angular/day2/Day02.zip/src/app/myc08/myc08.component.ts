import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc08',
  templateUrl: './myc08.component.html',
  styleUrls: ['./myc08.component.css']
})
export class Myc08Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
