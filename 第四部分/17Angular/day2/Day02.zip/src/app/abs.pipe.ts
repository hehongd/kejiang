import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'abs',
})
export class AbsPipe implements PipeTransform {
  // <p>{{ 9 | abs }}</p>

  transform(value: number) {
    return Math.abs(value);
  }
}
