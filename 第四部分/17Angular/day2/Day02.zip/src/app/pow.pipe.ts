import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pow',
})
export class PowPipe implements PipeTransform {
  // <p>{{ 2 | pow }}</p>
  // <p>{{ 2 | pow: 10 }}</p>

  // 带有默认值的参数, 如果参数2不传, 则默认值是2
  transform(value: number, exp = 2) {
    return Math.pow(value, exp);
  }
}
