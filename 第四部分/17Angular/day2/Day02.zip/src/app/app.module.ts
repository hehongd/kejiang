import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//引入
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { Work01Component } from './work01/work01.component';
import { Work02Component } from './work02/work02.component';
import { Myc01Component } from './myc01/myc01.component';
import { Myc02Component } from './myc02/myc02.component';
import { Myc03Component } from './myc03/myc03.component';
import { Myc04Component } from './myc04/myc04.component';
import { Myc05Component } from './myc05/myc05.component';
import { Myc06Component } from './myc06/myc06.component';
import { UpperDirective } from './upper.directive';
import { FocusDirective } from './focus.directive';
import { Myc07Component } from './myc07/myc07.component';
import { Myc08Component } from './myc08/myc08.component';
import { UpperPipe } from './upper.pipe';
import { PowPipe } from './pow.pipe';
import { AbsPipe } from './abs.pipe';

@NgModule({
  declarations: [AppComponent, Work01Component, Work02Component, Myc01Component, Myc02Component, Myc03Component, Myc04Component, Myc05Component, Myc06Component, UpperDirective, FocusDirective, Myc07Component, Myc08Component, UpperPipe, PowPipe, AbsPipe],
  // 添加
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
