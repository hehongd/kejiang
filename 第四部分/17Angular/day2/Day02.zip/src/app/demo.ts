// 简单减少 TS 语言最重要的特征:  静态类型 分析

// js语法: 不具备静态类型声明方式
function show(name) {
  // 对于vscode, 无法猜测到 name 是什么类型的; 所以并不能给出对应的代码提示!
  // return name.
}

// ts语法: 支持变量类型的声明
function show1(name: string) {
  // name:string  这是给vscode看的, 代表 name 是字符串类型
  // name.
}

// ts
// 要求严格

// 声明要一个参数name
function show2(name) {
  console.log(name);
}

// 使用时 没传递, 则报错!
show2();
