import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc07',
  templateUrl: './myc07.component.html',
  styleUrls: ['./myc07.component.css'],
})
export class Myc07Component implements OnInit {
  // 当前时间戳: 当前时间距离1970/1/1 的秒数
  now = new Date().getTime();

  url = 'http://xxxx/xx/x/xxx.x.x.x.x.xczxczczxczxc';

  constructor() {}

  ngOnInit(): void {}
}
