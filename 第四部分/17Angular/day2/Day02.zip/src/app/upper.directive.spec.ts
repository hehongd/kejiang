import { UpperDirective } from './upper.directive';

describe('UpperDirective', () => {
  it('should create an instance', () => {
    const directive = new UpperDirective();
    expect(directive).toBeTruthy();
  });
});
