import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work01',
  templateUrl: './work01.component.html',
  styleUrls: ['./work01.component.css'],
})
export class Work01Component implements OnInit {
  // 面向对象写法:  属性名 = 值;
  name = 'iPhone';
  price = 7999;
  count = 5;

  constructor() {}

  ngOnInit(): void {}
}
