import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'upper',
})
export class UpperPipe implements PipeTransform {
  // <p>{{ "hello" | upper }}</p>
  // 这是自动生成的代码, 官方也不知道 你的变量类型, 只能写 unknown
  transform(value: string) {
    // {{ value | upper }}
    // value 会自动传入此方法的参数1

    // 返回值 就是管道的处理结果
    return value.toUpperCase();
  }
}
