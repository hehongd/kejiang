// js
// 要求比较松散

// 声明要一个参数name
function show(name) {
  // 不传name 没关系, 默认值是 undefined
  console.log(name);
}

// 使用时没传递
show();
