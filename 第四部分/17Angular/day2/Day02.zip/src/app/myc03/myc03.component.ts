import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03',
  templateUrl: './myc03.component.html',
  styleUrls: ['./myc03.component.css'],
})
export class Myc03Component implements OnInit {
  names = ['亮亮', '然然', '东东', '华哥', '小新'];

  emps = [
    { name: '亮亮', age: 33, phone: '18787877777' },
    { name: '然然', age: 32, phone: '18787855577' },
    { name: '东东', age: 31, phone: '18787866677' },
    { name: '华哥', age: 30, phone: '18787888877' },
    { name: '小新', age: 29, phone: '18787899977' },
  ];

  constructor() {}

  ngOnInit(): void {}
}
