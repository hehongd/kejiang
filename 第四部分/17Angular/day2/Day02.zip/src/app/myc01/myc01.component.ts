import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
})
export class Myc01Component implements OnInit {
  num = 17;

  radius = 0;

  doCircle() {
    setInterval(() => {
      this.radius++;
    }, 100);
  }

  constructor() {}

  ngOnInit(): void {}
}
