import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc05',
  templateUrl: './myc05.component.html',
  styleUrls: ['./myc05.component.css'],
})
export class Myc05Component implements OnInit {
  vip = 1;

  constructor() {}

  ngOnInit(): void {
    let type = 1;
    switch (type) {
      case 1:
        console.log('111');
        break;
      case 2:
        console.log('222');
        break;
      default:
        break;
    }
  }
}
