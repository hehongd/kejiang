import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appUpper]',
})
export class UpperDirective {
  // 构造方法: 对象实例化时自动触发! -- 忘了的看东哥的JS高级部分
  constructor(e: ElementRef) {
    console.log(e);
    // e.nativeElement 就是当前指令所在的元素.  即原生DOM

    e.nativeElement.value = e.nativeElement.value.toUpperCase();
  }
}
