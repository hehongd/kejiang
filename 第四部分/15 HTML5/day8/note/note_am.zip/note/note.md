# `HTML5`新特性 -- `Unit08`

# 1.`SVG`

## 1.1 什么是`SVG`?

`SVG(Scalable Vector Graphic)`，可缩放的矢量图形，是基于`XML`语法的`2D`的矢量图形格式。

`SVG`的标准由`W3C`来制定和维护(https://www.w3.org/Graphics/SVG/)。

## 1.2 `SVG`与`Canvas`的区别

|          | SVG                                      | Canvas                   |
| -------- | ---------------------------------------- | ------------------------ |
| 分辨率   | 矢量图形，不依赖于分辨率                 | 位图图形，依赖于分辨率   |
| 事件处理 | 支持事件处理                             | 不支持单一对象的事件处理 |
| 应用方向 | 主要带有大型渲染区域的内容，如地图、图表 | 适用于网页动画、游戏等   |

## 1.3 `SVG`的使用方式

### • `<img>`标签

```html

<img src="SVG文件的URL地址">

```

示例代码如下：

```html

<div id="header">
    <img src="svg/logo.svg" width="150" height="90">
</div>

```

### • `CSS`中的`background-image` 属性

```css

selector{
	background-image:url(SVG文件的URL地址);
}

```

示例代码如下：

```html

<style>
    body{
        background: url(svg/background.svg);
        background-size: cover;
    }
</style>

```

### • `object`标签

```html

<object data="URL地址" type="MIME类型">
    浏览器不支持该类型的文件时显示的提示信息
</object>

```

> `SVG`文件的`MIME`类型为`image/svg+xml`

### • `<embed>`标签

```html

<embed src="URL地址" type="MIME类型" width="宽度" height="高度">
	浏览器不支持该类型的文件时显示的提示信息
</embed>

```

> `SVG`文件的`MIME`类型为`image/svg+xml`

示例代码如下：

```html

<embed src="svg/lowdetail.svg" type="image/svg+xml" width="223" height="300">
</embed>

```

### • `<iframe>`标签

```html

<iframe src="URL地址" width="宽度" height="高度">
</iframe>

```

示例代码如下：

```html

 <iframe 
         src="svg/iframe.svg" 
         width="400" 
         height="300"
         scrolling="no"
         frameborder="0">
</iframe>

```

### • `<svg>`标签

```html

<svg version="1.1" xmlns="http://www.w3.org/2000/svg">
    ...
</svg>

```

> `XMLNS(XML Namespace)`，译为`XML`命名空间，命名空间用于解决标记名称冲突

示例代码如下：

```html

<svg 
     width="200" 
     height="200" 
     version="1.1"
     xmlns="http://www.w3.org/2000/svg">
    <text x="50" y="50" font-size="50">SVG</text>
</svg>

```

## 1.4 `SVG`元素

### • 元素属性

• `stroke`属性用于控制描边的颜色

• `stroke-width`属性用于控制描边的宽度

### • `<line>`元素

`<line>`元素用于绘制线段，语法结构是：

```html

<line x1="start_x" y1="start_y" x2="end_x" y2="end_y"></line>

```

示例代码如下：

```html

<svg class="svg" version="1.1" xmlns="http://www.w3.org/2000/svg"  stroke-width="2" stroke="red">
    <line x1="50" y1="50" x2="150" y2="50"></line>
    <line x1="80" y1="80" x2="180" y2="80"></line>
    <line x1="50" y1="100" x2="150" y2="100"  stroke-width="5" stroke="blue">	</line>
</svg>

```

### • `<polyline>`元素

`<polyline>`元素用于绘制开放的折线，其语法结构是：

```html

<polyline points="x1,y1,x2,y2,...">
</polyline>

```



# 2.`ECharts`