# `HTML5`新特性 -- `Unit04`

# 1.`CanvasRenderingContext2D`接口

## 1.1 `measureText`属性

`measurtText`属性将返回一个可测量的文本对象，其语法结构是：

```javascript

TextMetrics CanvasRenderingContext2D.measureText(string text)

```

## 1.2 `TextMetrics`对象

### 1.2.1 `width`属性

`width`属性用于获取文本的宽度，语法结构是：

```javascript

variable = TextMetrics.width

```

