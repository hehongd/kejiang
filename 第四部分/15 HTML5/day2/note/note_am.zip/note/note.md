# `HTML5`新特性 -- `Unit02`

# 1.全屏`API`

全屏`API`用于控制某个`HTML Element`占满整个屏幕。

## • 进入全屏模式

```javascript

//W3C建议
HTMLElement.requestFullscreen()

//Chrome、safari、Opera浏览器
HTMLElement.webkitRequestFullScreen()

//Firefox
HTMLElement.mozRequestFullScreen()

//Internet Explorer/Edge
HTMLElement.msRequestFullscreen()

```

兼容浏览器的写法：

```javascript

function enterFullscreen(element){
	if(element.requestFullscreen){
    	element.requestFullscreen()
    } else if(element.webkitRequestFullScreen){
        element.webkitRequestFullScreen()
    } else if(element.mozRequestFullScreen){
        element.mozRequestFullScreen();
    } else if(element.msRequestFullscreen){
        element.msRequestFullscreen();
    }
}

```

## • 退出全屏模式

```javascript

//W3C建议
document.exitFullscreen()

//Chrome、safari、Opera
document.webkitExitFullScreen()

//Firefix
document.mozCancelFullScreen()

//Internet Explorer/Edge
document.msExitFullscreen()

```

兼容浏览器的写法：

```javascript

function exitFullscreen(){
    if(document.exitFullscreen){
		document.exitFullscreen();
    } else if(document.webkitExitFullScreen){
		document.webkitExitFullScreen();
    } else if(document.mozCancelFullScreen){
        document.mozCancelFullScreen();
    } else if(document.msExitFullscreen){
        document.msExitFullscreen();        
    }
}
```

## • `document.fullscreenElement`属性

`document.fullscreenElement`属性用于获取正处于全屏状态的`HTML`元素，如果当前没有`HTML`

元素处于全屏状态，则返回 `NULL`，其语法结构是：

```javascript

//W3C建议
document.fullscreenElement
//Chrome、Safari、Opera
document.webkitFullScreenElement
//Firefox
document.mozFullScreenElement
//Internet Explorer/Edge
document.msFullscreenElement

```

兼容浏览器的写法：

```javascript

function getFullscreenElement(){
	return  document.fullscreenElement ||
        	document.webkitFullScreenElement ||
        	document.mozFullScreenElement ||
        	document.msFullscreenElement;
}


```







