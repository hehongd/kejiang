//获取HTMLVideoElement对象
let videoEle = document.getElementById('video');
//获取播放/暂停的按钮对象
let controlButtonEle = document.getElementById('control-button');
//获取播放/暂停的图标对象
let controlIconEle = document.getElementById('control-icon');
//获取开启/关闭静音按钮
let volumeButtonEle = document.getElementById('volume-button');
//获取开启/关闭静音的图标对象
let volumeIconEle = document.getElementById('volume-icon');
//获取音量滑块对象
let volumeEle = document.getElementById('volume');

//播放/暂停按钮的事件
controlButtonEle.addEventListener('click', () => {
  //视频对象暂停或播放结束时,单击按钮时应播放视频,否则暂停视频
  if (videoEle.paused || videoEle.ended) {
    //媒体播放
    videoEle.play();
    //显示暂停图标
    controlIconEle.src = 'icons/pause.png';
  } else {
    //媒体暂停
    videoEle.pause();
    //显示播放图标
    controlIconEle.src = 'icons/play.png';
  }
});

//开启/关闭静音按钮的事件
volumeButtonEle.addEventListener('click', () => {
  videoEle.muted = !videoEle.muted;
  if (videoEle.muted) {
    //显示静音图标
    volumeIconEle.src = 'icons/volume-off.png';
    //调整音量滑块的值为0
    volumeEle.value = 0;
  } else {
    //显示非静音图标
    volumeIconEle.src = 'icons/volume-on.png';
  }
});

//音量滑动对象的事件
volumeEle.addEventListener('input', () => {
  //如果已静音,此时再向右滑动动块
  if (videoEle.muted) {
    //视频取消静音
    videoEle.muted = false;
    //显示非静音图标
    volumeIconEle.src = 'icons/volume-on.png';   
  }
  //如果当前音量滑动的值为0,则视频静音,并显示静音图标
  if(volumeEle.value == 0){
    //视频静音
    videoEle.muted = true;
    //显示静音图标
    volumeIconEle.src = 'icons/volume-off.png';
  } else {
    videoEle.muted = false;
    volumeIconEle.src = 'icons/volume-on.png';
  }
  //调整视频音量
  videoEle.volume = volumeEle.value;
});