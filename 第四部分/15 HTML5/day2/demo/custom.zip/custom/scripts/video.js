//获取HTMLVideoElement对象
let videoEle = document.getElementById('video');
//获取播放/暂停的按钮对象
let controlButtonEle = document.getElementById('control-button');
//获取播放/暂停的图标对象
let controlIconEle = document.getElementById('control-icon');

//播放/暂停按钮的事件
controlButtonEle.addEventListener('click', () => {
  //视频对象暂停或播放结束时,单击按钮时应播放视频,否则暂停视频
  if (videoEle.paused || videoEle.ended) {
    //媒体播放
    videoEle.play();
    //显示暂停图标
    controlIconEle.src = 'icons/pause.png';
  } else {
    //媒体暂停
    videoEle.pause();
    //显示播放图标
    controlIconEle.src = 'icons/play.png';
  }
});