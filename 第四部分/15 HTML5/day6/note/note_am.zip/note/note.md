# `HTML5`新特性 -- `Unit06`

# 1.`WebStorage`

## 1.1 概述

`web storage`提供了一种比`cookie`更加直观方式来存储数据，其结构为键/值对

`web storage`中提供两种存储机制：

`localStorage`，为每个指定的源维护一个独立的区域，该区域中的数据即使在浏览器关闭后仍然存在，除非人为手动清除。

`sessionStorage`，为每个指定的源维护一个独立的区域，该区域中的数据只在浏览器的会话期间有效。

这两种机制可以通过`window.sessionStorage`和`window.localStorage`进行访问。

## 1.2 `sessionStorage`

### • `setItem()`方法

`setItem()`方法用于将键名添加到`sessionStorage`中，如果键名存在，则更新键值，语法结构是：

```javascript

window.sessionStorage.setItem(key,value)

```

### • `getItem()`方法

`getItem()`方法用于获取`sessionStorage`中指定键名的值，语法结构是：

```javascript

window.sessionStorage.getItem(key)

```

### • `removeItem()`方法

`removeItem()`方法用于删除指定键名，语法结构是：

```javascript

window.sessionStorage.removeItem(key)

```

### • `clear()`方法

`clear()`方法用于删除所有的键名，语法结构是：

```javascript

window.sessionStorage.clear()

```

### •  `length`属性

`length`属性用于获取`sessionStorage`中存储的成员数量，语法结构是：

```javascript

variable = window.sessionStorage.length

```

### • `key()`方法

`key()`方法用于返回指定索引值的键名，**但需要注意的是：键名的顺序由浏览器决定！**

```javascript

varible = window.sessionStorage.key(index)

```

>  **该方法不能用于生产环境**

## 1.3 `localStorage`

### • `setItem()`方法

`setItem()`方法

`setItem()`方法用于将键名添加到`localStorage`中，如果键名存在，则更新键值，语法结构是：

```

window.localStorage.setItem(key,value)

```

### • `getItem()`方法

`getItem()`方法

`getItem()`方法用于获取`localStorage`中指定键名的值，语法结构是：

```

window.localStorage.getItem(key)

```

### • `removeItem()`方法

`removeItem()`方法用于删除指定键名，语法结构是：

```javascript

window.localStorage.removeItem(key)

```

### • `clear()`方法

`clear()`方法用于删除所有的键名，语法结构是：

```javascript

window.localStorage.clear()

```

### •  `length`属性

`length`属性用于获取`localStorage`中存储的成员数量，语法结构是：

```javascript

window.localStorage.length

```

### • `key()`方法

`key()`方法用于返回指定索引值的键名，**但需要注意的是：键名的顺序由浏览器决定！**

```

variable = window.localStorage.key(index)

```

>  **该方法不能用于生产环境**

# 2.`Vuex`

## 2.1 什么是 `Vuex`?

`Vuex`是一个专门为`Vue`开发的应用程序状态管理模式。其实就是通过`Vuex`实现在各个组件中的数据共享。应用场景如：用户登录、购物车信息等。

## 2.2 安装

```shell

npm install --save vuex

```

> 如果在安装脚手架时已经选择`Vuex`，则无须再进行安装操作了







