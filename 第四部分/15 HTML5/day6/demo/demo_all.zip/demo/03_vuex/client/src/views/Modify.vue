<template>
  <div>    
      <h1>这是03目录下的效果</h1>
      <button @click="increment">增加年龄</button>
      <button @click="decrement">减少年龄</button>
      <button @click="add">带有参数的增加年龄(每次加5岁)</button>
      <h1>年龄是:{{this.$store.state.age}}</h1>
  </div>
</template>
<script>
import {mapMutations} from 'vuex';
export default {
  methods: {
    // ...mapMutations([
    //   'age_increment_mutation',
    //   'age_decrement_mutation',
    //   'age_add_mutation'
    //   ]),
    ...mapMutations({
      a:'age_increment_mutation',
      b:'age_decrement_mutation',
      c:'age_add_mutation'
    }),
    //增加年龄
    increment(){
        //调用了仓库中名称为age_increment_mutation的理货员
        //this.$store.commit('age_increment_mutation');
        //this.age_increment_mutation();
        this.a();
    },
    //减少年龄
    decrement(){
       //调用了仓库中名称为age_decrement_mutation的理货员
        //this.$store.commit('age_decrement_mutation');
        //this.age_decrement_mutation();
        this.b();
    },
    //调用按指定参数增加年龄的理货员
    add(){
      //this.$store.commit('age_add_mutation',5);
      //this.age_add_mutation(5);
      this.c(5);
    }
  },
}
</script>