# `HTML5`新特性 -- `Unit03`

# 1.`CanvasRenderingContext2D`接口

## 1.1 绘制文本

### • `textAlign` 属性

`textAlign`属性用于获取/设置文本的水平对齐方式，其语法结构是：

```javascript

//设置
CanvasRenderingContext2D.textAlign = 'left|center|right'

//获取
variable = CanvasRenderingContext2D.textAlign

```

## 1.2 路径

路径（`path`）是将预先定义的坐标点顺序连接形成的图形。

> 路径在进行描边或填充之前在画布不可见

### • 路径的绘制步骤

A、通过`beginPath()`方法开始一条新路径

B、通过`moveTo()`方法定义路径起点

C、定义路径的内容(如`rect()`方法用于绘制矩形路径，`arc()`方法用于绘制圆弧等)

D、通过`stroke()`或`fill()`方法进行描边或填充

### • `beginPath()`方法

`beginPath()`方法用于清空之前的子路径，开始一个新的路径，语法结构是：

```javascript

CanvasRenderingContext2D.beginPath()

```

### • `moveTo()`方法

`moveTo()`方法用于移动新路径的起点到指定的位置，其语法结构是：

```javascript

CanvasRenderingContext2D.moveTo(x,y)

```

### • `lineTo()`方法

`lineTo()`方法实现使用直线连接路径终点，语法结构是：

```javascript

CanvasRenderingContext2D.lineTo(x,y)

```

### • `closePath()`方法

`closePath()`方法用于返回当前路径的起点，语法结构是：

```javascript

CanvasRenderingContext2D.closePath()

```

### • `stroke()`方法

`stroke()`方法用于根据当前的描边样式绘制当前路径，语法结构是：

```javascript

CanvasRenderingContext2D.stroke()

```

### • `fill()`方法

`fill()`方法用于根据当前的填充样式绘制当前路径，语法结构是：

```javascript

CanvasRenderingContext2D.fill()

```





