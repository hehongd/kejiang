<template>
  <div>
    <mt-header title="学前端,到学问" fixed>
      <router-link to="/" slot="left">
        <mt-button icon="back"></mt-button>
      </router-link>
      <router-link to="/" slot="right">
        <mt-button icon="more"></mt-button>
      </router-link>
    </mt-header>
    <div style="margin-top: 40px">
      <p>11</p>
      <p>22</p>
      <p>33</p>
      <p>44</p>
      <p>55</p>
    </div>
  </div>
</template>