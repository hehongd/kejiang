<template>
  <div>
    <mt-button type="primary" icon="back"></mt-button>
    <mt-button type="primary" icon="more"></mt-button>
    <mt-button type="default">默认</mt-button>
    <mt-button type="primary">主要</mt-button>
    <mt-button type="danger">危险</mt-button>
    <mt-button size="small" type="primary">小的</mt-button>
    <mt-button size="normal" type="primary">默认</mt-button>
    <mt-button size="large" type="primary">大的</mt-button>
    <mt-button size="large" type="primary" plain>大的</mt-button>
  </div>
</template>