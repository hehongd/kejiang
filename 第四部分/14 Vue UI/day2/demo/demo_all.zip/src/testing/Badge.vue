<template>
  <div>
    <p><mt-badge type="primary">100</mt-badge></p>
    <p><mt-badge type="success">100</mt-badge></p>
    <p><mt-badge type="warning">100</mt-badge></p>
    <p><mt-badge type="error">100</mt-badge></p>
    <p><mt-badge size="small">100</mt-badge></p>
    <p><mt-badge size="normal">100</mt-badge></p>
    <p><mt-badge size="large">100</mt-badge></p>
    <p><mt-badge size="large" color="#900">100</mt-badge></p>
  </div>
</template>