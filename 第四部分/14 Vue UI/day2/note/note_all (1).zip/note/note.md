# `Mint UI` - `Unit02`

# 1.作业

在`Mint UI `组件中，`<field>`组件的获取/失去焦点的写法是：

```html

<mt-field 
	@blur.native.capture="函数名称"
	@focus.native.capture="函数名称">
</mt-field>

```

> `Vue.js`的事件修饰符
>
> https://cn.vuejs.org/v2/guide/events.html#%E4%BA%8B%E4%BB%B6%E4%BF%AE%E9%A5%B0%E7%AC%A6
>
> 非必要情况下，不能在`<template>`中写过多的业务逻辑代码。

# 2. 组件

## · `Navbar` 组件

`Navbar`组件用于实现顶部选项卡，其语法结构是：

```html

<mt-navbar v-model="变量名称(被选定的选项的ID)" fixed>
    <mt-tab-item id="当前选项卡的ID">...</mt-tab-item>
    ...
</mt-navbar>

```

> `fixed`属性用于控制是否在页面顶部固定顶部选项卡，布尔属性
>
> `<mt-tab-item>`的`id`属性只需要保证在当前的`<mt-navbar>`中唯一即可
>
> 在`<mt-tab-item>`中可以嵌套图片，如果为图片添加`slot="icon"`属性的话，此时图片将作为选项卡的图标出现。

## · `TabContainer` 组件

`TabContainer`组件用于实现面板，其语法结构是：

```html

<mt-tab-container v-model="变量名称(被选定面板的ID)" swipeable>
    <mt-tab-container-item id="当前面板的ID">...</mt-tab-container-item>
    ...
</mt-tab-container>

```

> `swipeable`属性用于控制面板在切换时是否具有滑动效果，布尔属性
>
> 如果让顶部选项卡在切换时面板随之发生变化的话，有两种解决方案：
>
> 第一种：面板与顶部选项卡绑定相同的变量，且面板项目的`ID`与顶部选项卡项目的`ID`相同，示例代码如下：
>
> ```html
> 
> <div>  
> 
> <mt-navbar v-model="active">
>     <mt-tab-item id="a">
>         HTML5
>         <img src="../assets/images/html5.png" alt="" slot="icon" />
>     </mt-tab-item>
>     <mt-tab-item id="b">
>         CSS3
>         <img src="../assets/images/css3.png" alt="" slot="icon" />
>     </mt-tab-item>
>     <mt-tab-item id="c">
>         JavaScript
>         <img src="../assets/images/js.png" alt="" slot="icon" />
>     </mt-tab-item>
> </mt-navbar>
> </div>
> <div class="main">
>     <!-- 面板开始 -->
>     <mt-tab-container v-model="active">
>         <mt-tab-container-item id="a">11</mt-tab-container-item>
>         <mt-tab-container-item id="b">22</mt-tab-container-item>
>         <mt-tab-container-item id="c">33</mt-tab-container-item>
>     </mt-tab-container>
>     <!-- 面板结束 -->
> </div>
> </div>
> 
> ```
>
> 第二种：如果顶部选项卡与面板绑定的变量不同的话，但仍然需要在切换顶部选项卡时面板随之发生变化，此时只能通过监听顶部选项卡的变量来实现，示例代码如下：
>
> ```html
> 
> <template>
>     <div>
>         <mt-navbar v-model="active">
>         	<mt-tab-item id="a">HTML5</mt-tab-item>
>             <mt-tab-item id="b">CSS3</mt-tab-item>
>             <mt-tab-item id="c">JavaScript</mt-tab-item>
>         </mt-navbar>
>         <mt-tab-container v-model="selected">
>             <mt-tab-container-item id="item01">
>                 11
>             </mt-tab-container-item>
>             <mt-tab-container-item id="item02">
>                 22
>             </mt-tab-container-item>
>              <mt-tab-container-item id="item03">
>                 33
>             </mt-tab-container-item>
>         </mt-tab-container>
>     </div>
> </template>
> <script>
>     export default{
>         data(){
>            return {
>                 active:"a",
> 	            selected:"item01"
>            }
>         },
>         watch:{
>             active(value){
>                   if (value == "a") {
>                     this.selected = "item01";
>                   } else if (value == "b") {
>                     this.selected = "item02";
>                   } else if (value == "c") {
>                     this.selected = "item03";
>                   }
>             }
>         }
>     }
> </script>
> 
> ```

## · `TabBar` 组件

`TabBar`组件用于实现底部选项卡，其语法结构是：

```html

<mt-tabbar v-model="变量名称(被选定选项卡的ID)" fixed>
    <mt-tab-item id="当前选项卡的ID">...</mt-tab-item>
    ...
</mt-tabbar>

```

> 在`<mt-tab-item>` 中可以嵌套图片，如果为图片添加`slot="icon"`属性的话，图片将作为选项卡的图标出现。
>
> `TabBar`实现链接的方式有两种：
>
> A.直接在`<mt-tab-item>`标签上添加`href`属性即可 -- 因为`<mt-tab-item>`编译之后形成的是`a`标签，所以添加`href`即可（不建议使用）。
>
> B.通过监听`<mt-tabbar>`绑定的变量，然后通过`this.$router.push()`的方法来实现页面的跳转，示例代码如下：
>
> ```html
> 
> <script>
>     export default{
>         watch:{
>             selectedTab(value) {
>                 if (value == "index") {
>                     this.$router.push("/");
>                 } else if (value == "me") {
>                     this.$router.push("/me");
>                 }
>             }
>         }
>     }
> </script>
> 
> ```

## · `Badge` 组件

`Badge`组件用于实现徽章，其语法结构是：

```html

<mt-badge type="类型" size="尺寸" color="颜色">
    ...
</mt-badge>

```

> `type`属性值可以为：`primary`(主要的)、`success`(成功的)、`warning`(警告)、`error`(错误)
>
> `size`属性值可以为：`small`(小的)、`normal`(标准的)、`large`(大的)
>
> `color`属性允许用户自定义颜色

## · 路由传参的方式

第一种：直接以`URL`地址栏参数进行传递，示例代码如下：

```html

<router-link to="/article?id=1&mid=6">...</router-link>

```

第 二种：直接`PathInfo`模式进行传递，此时需要分为两步操作：

A、定义路由，示例代码如下：

```javascript

const routes = [
    {
        path:'/article/:id',
        component:Article
    }
]

```

B、书写链接，示例代码如下：

```php+HTML

<router-link to="/article/5">...</router-link>

```

作业：

A.必须保证`XAMPP`中的`MySQL`可以正常启动

B.复习`MySQL`中常用的命令 -- `SELECT`