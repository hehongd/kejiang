# `Mint UI` - `Unit06`

# 1.`Moment.js`

`Moment.js`是可以运行在浏览器端和移动端的、基于`JavaScript`的日期时间类库。

## 1.1安装

浏览器

```html

<script src="moment.js文件URL地址"></script>

```

`NPM`环境

```shell

npm install --save moment

```

## 1.2 `NPM`配置

 在`main.js`中实现以下操作：

```javascript

import moment from 'moment';

Vue.prototype.moment = moment;

```

## 1.3 使用`Moment`对象

### 1.3.1 构建`Moment`对象

```javascript

//以当前的日期和时间为基准来构建Moment对象
moment(); 
//以指定的日期或日期时间来构建Moment对象
moment('日期或日期时间')
//以指定的毫秒时间戳来构建Moment对象
moment(毫秒时间戳)
//以指定的时间戳来构建Moment对象
moment.unix(时间戳)

```

### 1.3.2 格式化

```javascript

Moment对象.format("格式")

```

> 常见的格式有：
>
> `Y`：四位的年份
>
> `MM`：两位的月份
>
> `DD`：两位的日期
>
> `HH`：两位的小时
>
> `mm`：两位的分钟
>
> `ss`：两位的秒	

# 2.用户注册业务的实现

2.1.脚手架发送用户注册的请求

用户注册时，需要首先在客户端进行用户名、密码及确认密码的校验工作，在其都正确的情况下，应该将用户名、密码信息的提交到服务器，示例代码如下：

```



```

此时脚手架的运行结果如下图所示：

![image-20201204113248920](assets/image-20201204113248920.png)

## 2.2.服务器上创建相关的接口并且接收和处理数据

因为脚手架的提交方式为`POST`，所以需要在服务器上安装`body-parser`模块，以获取`POST`提交的数据（在`Express4.5`之后的版本中已经自带有`body-parser`模块）

安装 

```shell

npm install --save body-parser

```

配置

```javascript

const bodyParser = require('body-parser');

server.use(bodyParser.urlencoded({
  extended:false
}));

```

服务器上创建相关的接口并且接收和处理数据，示例代码如下：

```javascript

server.post('/register',(req,res)=>{
  //获取用户名和密码信息
  let username = req.body.username;
  let password = req.body.password;
  // 先需要以username为条件进行用户的查找操作
  let sql = 'SELECT COUNT(id) AS count FROM xzqa_author WHERE username=?';
  // 执行SQL查询
  pool.query(sql,[username],(error,results)=>{
    if(error) throw error;
    console.log(results[0].count);
  });
  
});

```

> 在`MySQL`进行插入记录操作时，必须为禁止为空且没有默认值的字段进行赋值操作，否则产生语法错误！！！
>
> 页面中的表单表现其实就是数据表结构的映射！

脚手架最终的代码如下：

![image-20201204154852033](assets/image-20201204154852033.png)

服务器接口的最终代码如下：

![image-20201204155019304](assets/image-20201204155019304.png)

## 2.3 `MessageBox`组件

`MessageBox`组件用于显示模态对话框，其语法结构是：

```javascript

//简捷语法
this.$messagebox("标题","提示内容")
//标准语法
this.$messagebox.alert("提示内容","标题")
this.$messagebox.confirm("提示内容","标题")
this.$messagebox.prompt("提示内容","标题")

```

## 2.4 密码加密

密码加密在`Node.js`的`MySQL`环境下，使用通过以下两种方式实现：

A.直接通过`MySQL`数据库的`MD5()`函数实现，示例代码如下：

```mysql

SELECT MD5('12345678');

```

B.在`Node.js`环境下安装并且使用`MD5`的模块

安装

```shell

npm install --save md5

```

使用

```javascript

const md5 = require('md5');

md5("字符串")

```

> 在`MySQL`中修改当前用户密码的命令是：
>
> ```mysql
> 
> SET PASSWORD=PASSWORD('新密码')
> 
> ```

# 3.用户登录的业务实现

## 3.1 脚手架发送登录的请求

用户登录的业务实现的需要在`Login.vue`中完成，此时先需要进行用户名及密码规则的校验，当校验成功后，需要将用户名和密码信息发送到服务器的相关接口，示例代码如下：

```javascript

this.axios.post('/login','username=' + this.username + '&password=' + this.password).then(res=>{
	//...
});

```

此时客户端的运行结果如下图所示：

![image-20201204163731596](assets/image-20201204163731596.png)

### 3.2 在服务器上创建接口并且接收和处理数据

在服务器上创建接口，示例代码如下：

```javascript

server.post('/login',(req,res)=>{
	//...
});

```

服务器的`/login`的接口代码如下：
![image-20201204175200560](assets/image-20201204175200560.png)

脚手架的代码如下：

![image-20201204175434097](assets/image-20201204175434097.png)