# `Mint UI` - `Unit05`

# 1.作业

## 1.1 函数的封装

在`Index.vue`中`mounted`、无限滚动及切换顶部选项卡时，都需要从服务器的`articles`接口中获取数据，而且业务基本上是相同的，所以建议该过程封装为函数。

![image-20201203094553538](assets/image-20201203094553538.png)

## 1.2 超出总页数的无限滚动

如果超出总页数的情况下，既使再次向下滚动，也不在发送请求，实质上是代码如下：

```javascript

// 向下滚动时调用的方法
loadMore() {
    // 页码累加
    this.page++;
    // 调用loadData()方法
    if(this.page <= 总页数){
    	this.loadData(this.active,this.page);
    }
}

```

在如上的结构中，唯独不确定的是  --- **总页数**

现在必须修改`/articles`接口，除原来返回的数据外，再返回总页数即可。

总页数的标准计算公式是：

```javascript

Math.ceil(总记录数 / 每页显示的记录数量)

```

如何获取总记录数？

```sql

SELECT COUNT(id) AS count FROM 数据表 [....]

```

> `MySQL`中的聚合函数(只有一个返回结果且可以使用在`HAVING`子句中)：
>
> `COUNT`,计数
>
> `SUM`，求和
>
> `MIN`，最小值
>
> `MAX`，最大值
>
> `AVG`，平均值

```mysql

SELECT express[,...]
[FROM table_references]
[WHERE condition]
[GROUP BY col_name]
[HAVING condition]
[ORDER BY col_name [ASC|DESC][,...]]
[LIMIT [offset,]row_count]

```

> `WHERE`子句中不能带有聚合函数；`HAVING`子句中可以带有聚合函数。

## 2.文章详情页面的业务实现

在`Index.vue`中链接到文章详情页面的结构如下：

```html

<router-link :to="`/article/${article.id}`">
    ...
</router-link>

```

关于`Article`页面组件的路由规定如下：

```javascript

{
    path:'/article/:id',
    component:Article
}

```

此时访问某一篇文章的链接，其运行结果如下图所示：

![image-20201203114700901](assets/image-20201203114700901.png)

现在必须首先要获取到文章的`id`，然后再去服务器获取该篇文章的详细信息。

所以...

## 2.1 获取文章`id`并且发送请求

在`Vue.js`中通过链接传递参数的方式有两种：

第一种：

```html

<router-link to="/articles?id=100">...</router-link>

```

接收参数

```javascript

this.$route.query.id

```

第二种：

```html

<router-link to="/articles/100">...</router-link>

```

```javascript

this.$route.params.id

```

`router`对象进行路由的跳转，常用的方法有：

> `router.push(sting url)`
>
> `router.replace(string url)`
>
> `router.back()`
>
> `router.forward()`
>
> `router.go(n)`

`route`对象用于获取路由的相关参数，常用的属性有：

> `route.params`用于获取地址栏中动态参数片断（形如 `/article/236`，其名称来源于路由的写法，如
>
> ```
> 
> {
> 	path:'/article/:id',
> 	component:Article
> }
> ```
>
> `route.query`用于获取通过`URL`地址栏传递的参数，形如:`/article?id=1&cid=3`

获取文章`id`的操作在页面加载完成后就应该被得到，所以需要在`Article.vue`中`mounted`中实现，代码如下：

```javascript

let id = this.$route.params.id;

```

 现在获取到`id`的情况下，就需要向服务器发送请求，以获取数据到，示例代码如下：

```javascript

this.axios.get('/review',{
    params:{
        id:id
    }
}).then(res=>{

});

```

此时脚手架运行的结果如下图所示：

![image-20201203143005588](assets/image-20201203143005588.png)

产生错误的原因是：服务器根本不存在名称为`review`的`GET`类型的接口

所以...

## 2.2 定义服务器接口并且返回数据

需要在服务器上定义名称为`/review`的`GET`类型的接口，示例代码如下:

```javascript

// 获取指定的文章信息
server.get('/review',(req,res)=>{
    // 获取地址栏的URL参数 -- 文章ID
    let id = req.query.id;
    // 查询特定记录的SQL语句
    let sql = 'SELECT r.id,subject,content,created_at,nickname,avatar,article_number FROM xzqa_article AS r INNER JOIN xzqa_author AS u ON author_id = u.id WHERE r.id=?';

    // 执行SQL语句
    pool.query(sql,[id],(error,results)=>{
        if(error) throw error;
        res.send({code:200,message:"查询成功",result:results[0]});
    }); 

});

```

此时脚手架的运行结果如下图所示：

![image-20201203153128174](assets/image-20201203153128174.png)

## 2.3 脚手架接收并且显示数据

脚手架是在`mounted` 时发送的请求，也就需要在`mounted`的时候来接收数据，而且接收的数据还需要在页面中进行展示，所以还需要`data()`中声明属性用于存储服务器返回的数据



作业：

日期和时间现在在数据表中以时间戳（`timestamp`，从公元`1970-01-01 00:00:00`到现在经历的秒数，也称为`Unix`纪元）的方式进行存储的，要将时间戳转换为可阅读的日期和时间 -- `Moment.js`

http://momentjs.cn/