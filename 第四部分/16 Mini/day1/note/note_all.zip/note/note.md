# 微信小程序 `Unit01`

# 1.微信公众平台

## 1.1 微信公众平台概述

微信公众平台，是基于腾讯提供的微信服务器和客户端`APP`，由更多的第三服务提供者加入，为广大的微信客户端提供咨讯和服务的平台。

微信公众平台域名：https://mp.weixin.qq.com

微信公众平台的服务类型：

• 服务号，对客户提供一对一的服务，如中国移动、中国联通、招商银行等。

• 订阅号，向所有的订阅者提供免费的咨讯服务，如前端大全、`MSDN`等

• 小程序，在微信客户端提供类似`APP`功能，达到"用完即走"的目的

• 企业号，为企业内部员工提供日常办公支持，可与微信、支付等互通。

## 1.2 微信小程序的历史

• 2010年微信内自带`WebView`组件（其本质就是`HTML`/`CSS`/`JavaScript`的解释器）提供网页浏览服务，其在微信内部成为网页的标准，但未公开。

• 2015年,腾讯公开一套网页开发工具包，称为`JS-SDK`,开放了拍摄、录音、支付等功能。

• 2017年推出微信小程序

• 2019年支付宝、头条等陆续推出了小程序

## 1.3 微信小程序与网页的开发的区别

| 普通网页                                      | 微信小程序                            |
| --------------------------------------------- | ------------------------------------- |
| `HTML`标记，由`W3C`制定和维护                 | `WXML`,由微信小程序提供的页面组件     |
| `CSS`样式，由`W3C`制定和维护                  | `WXSS`,由微信小程序提供的样式语言     |
| `JavaScript`控制页面行为(`ES`、`DOM`、` BOM`) | `WXS`(`ES`)，由`ECMAScript`提供的脚本 |
| 渲染线程与脚本线程是同一线程，也就是互斥的    | 渲染线程与脚本线程是两个独立线程      |
| 可以使用`DOM`与`BOM`操作                      | 不能进行任何的`DOM`和`BOM`操作        |

# 2.微信小程序开发环境搭建

## 2.1 注册微信小程序开发者

A.注册全新邮箱(或者使用没有在微信公众平台注册过的邮件，如`QQ`邮箱)

B.在微信公众平台注册开发者账号，步骤如下：

![image-20200717104634486](assets/image-20200717104634486.png)

![image-20200717104658170](assets/image-20200717104658170.png)

![image-20200717104826937](assets/image-20200717104826937.png)



**项目目录名称中禁止出现中文、空格等特殊符号**

## 2.2 创建微信小程序项目

![image-20200717113853779](assets/image-20200717113853779.png)

![image-20200717120116309](assets/image-20200717120116309.png)

## 2.3 微信小程序目录结构

• `.json` ,静态配置文件

​	 • `app.json`，整个项目的全局配置文件

​	•  `page.json`,每个页面专用的配置文件（如`index.json`、`logs.json`），可覆盖全局配置

• `.js/.ts`,脚本文件

​	 • `app.js`，整个小程序应用的入口脚本文件

​	 • `page.js`,每个页面专用的脚本文件,如`index.js`、`logs.js`等

• `.wxml`，页面的模板文件（不能使用`HTML`标签，只使用小程序专用的标签）

• `.wxss`，页面的样式文件

​	 • `app.wxss`,整个小程序应用的全局样式文件

​	 • `page.wxss`,每个页面的样式文件，可覆盖全局样式

> `app.json`、`app.js`、`app.wxss`必须在小程序应用的根目录下

## 2.4 `JSON`

`JSON`官网：https://www.json.org/json-en.html

`JSON`(`JavaScript Object Notation`) 是一种轻量级的数据交换格式。

`JSON`支持的数据结构有：`Array`和`Object`

![](assets/array.png)



![object](assets/object.png)

`JSON`支持的数据类型有：`string`、`number`、`boolean`、`null`、`array`、`object`

**`string`必须括在英文双引号之间**![string](assets/string.png)

`Number`类型的结构如下：

![number](assets/number.png)

## 2.5 全局配置 

全局配置存储在`app.json`文件内，示例结构如下：

```json

{
    "pages":[],
    "window":{
        "navigationBarTitleText": "标题文本内容 ",
        "navigationBarTextStyle":"标题文本颜色(white|black)",
        "navigationBarBackgroundColor": "标题背景颜色",
        "backgroundTextStyle":"loading的样式(dark|light)",
        "enablePullDownRefresh":true,
        "backgroundColor": "背景颜色"
    },
    "tabBar":{
        "list":[
            {
                "text": "显示文本",
                "pagePath": "链接页面路径",              
                "iconPath": "默认显示的图标路径",
                "selectedIconPath": "被选定时显示的图标路径"
            }
        ]
    }
}

```

> `pages`属性用于指定小程序中的页面组成，每个页面默认包括`page.json`、`page.js`、`page.wxss`及`page.wxml`文件。数组的第一项代表小程序的初始页面（首页）
>
> `window`属性用于进行窗口的配置，为`object`类型，包含有：
>
> - `navigationBarTitleText`,控制标题的文本内容
> - `navigationBarTextStyle`,控制标题的文本样式（`black|white`）
> - `navigationBarBackgroundColor`，控制标题的背景颜色
> - `backgroundTextStyle`，用于控制下拉刷新时的`loading`的样式(`light|dark`)
> - `enablePullDownRefresh`,用于控制是否开启全局下拉刷新(也可以`page.json` 中对于某个页面进行单独的配置)
> - `backgroundColor`,窗口的背景颜色
>
> `tabBar`属性用于设置小程序底部选项卡，为`object`,包含`list`属性，在`list`属性需要罗列底部选项卡信息（选项卡数量至少两个，至多五个）,包含有以下信息：
>
> - `text`，控制底部选项卡显示的文本
> - `pagePath`，控制底部选项卡的链接页面路径（必须保证在路径已经在`pages`中存在）
> - `iconPath`，控制正常显示选项卡图片
> - `selectedIconPath`,控制被选定的选项卡图片
>
> 除此之外，在`tabBar`中还有包含以下属性：
>
> - `color`，控制底部选项卡文本正常显示的颜色
> - `selectedColor`，控制被选定的底部选项卡文本的颜色
> - `backgroundColor`，控制底部选项卡的背景颜色
> - `borderStyle`,控制底部选项卡中顶部边框线的颜色(`black|white`)

 `app.json`的示例代码如下：

```JSON

{
  "pages": [
    "pages/index/index",
    "pages/page01/page01",
    "pages/logs/logs"
  ],
  "window": {
    "navigationBarTitleText": "学子影院",
    "navigationBarTextStyle": "white",
    "navigationBarBackgroundColor": "#0aa1eb",
    "backgroundTextStyle": "light",
    "enablePullDownRefresh": true,
    "backgroundColor": "#e5e5e5"
  },
  "tabBar": {
    "color": "#000",
    "selectedColor": "#0aa1eb",
    "backgroundColor": "#fff",
    "borderStyle":"black",
    "list": [
      {
        "text": "首页",
        "pagePath": "pages/index/index" ,
        "iconPath" :"images/index_disabled.png",
        "selectedIconPath":"images/index_enabled.png"
      },
      {
        "text": "购物车",
        "pagePath": "pages/page01/page01"  ,
        "iconPath" :"images/cart_disabled.png",
        "selectedIconPath":"images/cart_enabled.png"    
      }
    ]
  }, 
  "style": "v2",
  "sitemapLocation": "sitemap.json"
}

```

## 2.6 `sitemap.json`

`sitemap.json`用于设置微信爬虫的爬取规则。

`sitemap.json`的文档结构如下：

```json

{
	"rules":[
		{
			"page":"页面的路径",
            "action":"动作",
            "params":[],
            "matching":"匹配规则(exact|inclusive|exclusive|partial)"
		}
	]
}

```

> 可配置`project.config.json`中的`checkSiteMap`属性禁用`siteMap`属性

# 3.微信小程序组件

## • `<view>`组件

`<view>`组件视图容器组件，语法结构是：

```html

<view 
      hover-class="按下去的样式类"
      hover-start-time="按下去多长时间出现点击状(50ms)"
      hover-stay-time="手指松开后点击状态的保留时间(400ms)">
    ...
</view>

```

示例代码如下：

```html
<--page.xwml代码如下：-->
    
<view 
  class="container"
  hover-class="hover"
  hover-start-time="3000"
  hover-stay-time="5000">
  view组件是视图容器组件，类似于HTML中DIV
</view>

```

```css

/*page.wxss的代码如下:*/
.container{
  width:200px;
  height: 200px;
  border:2px solid #f00;
}
.hover{
  border:2px dotted #00f;
}

```

## • `<image>`组件

`<image>`组件是图片组件，支持`GIF`、`JPG`、`PNG`、`WEB`、`SVG`格式的文件，语法结构如下：

```html

<image src="图像的URL地址"></image>

```