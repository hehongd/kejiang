# 微信小程序 - `Unit02`

# 1.`WXSS`

`WXSS(Weixin Style Sheets)`是一套样式语言，用于描述`WXML`的组件样式。

## • 尺寸单位 --  `rpx`

`rpx(Responsive Pixel)`,可以根据屏幕宽度进行自适应，规定屏幕尺寸为`750rpx`

| 手机设备              | rpx2px         | px2rpx        |
| --------------------- | -------------- | ------------- |
| iPhone5(320/750)      | 1rpx = 0.42px  | 1px = 2.34rpx |
| iPhone6(375/750)      | 1rpx = 0.5px   | 1px = 2rpx    |
| iPhone6 Plus(414/750) | 1rpx = 0.552px | 1px = 1.81rpx |

## • 样式导入

样式导入的语法结构是：

```css

@import "wxss样式文件的路径及名称";

```

# 2.组件

## • `<image>`组件

`<image>`组件是图片组件，支持`GIF`、`JPG`、`PNG`、`WEB`、`SVG`格式的文件，语法结构如下：

```html

<image 
       src="图像的URL地址" 
       lazy-load="是否懒加载"
       mode="图像的裁切、缩放的模式"></image>

```

> `<image>`组件默认的尺寸为`300X240`
>
> `mode`常用的模式有：
>
> `scaleToFill`,缩放模式，不保持横纵比
>
> `aspectFit`,缩放模式，保持横纵比，使图像的长边显示出来
>
> `aspectFill`，缩放模式，保持横纵比，使图像的短边显示出来

## • `<swiper>`组件

`<swiper>`组件用于实现滑块视图容器，其语法结构是：

```html

<swiper
    autoplay="是否自动播放"
    indicator-dots="是否显示面板指示点"
    indicator-color="指示点正常显示的颜色"
    indicator-active-color="指示点被选定的颜色"
    circular="是否采用衔接滑动"
    interval="自动切换的时间间隔(5000ms)"
    duration="切换的时长(500ms)"
    easing-function="动画类型">
	<swiper-item>...</swiper-item>
    ...
</swiper>

```

> 动画类型包括：
>
> `linear`:线性动画
>
> `easeInCubic`,缓入动画
>
> `easeOutCubic`,缓出动画
>
> `easeInOutCubic`，缓入和缓出动画

## • `<text>`组件

`<text>`组件用于实现文本，语法结构是：

```html

<text selectable="是否可选" decode="是否解码"></text>

```

示例代码如下：

```html

<text selectable="true">我是可选定的文本(需在真机模式下调试)</text>
<text>A&gt;B,B&lt;A</text>
<text decode="true">A&gt;B,B&lt;A,Tom&amp;John</text>

```

> 微信小程序的解码只支持：`&nbsp;`、`&gt;`、`&lt;`、`&amp;`及`&apos;`
>
> 以上五个称为HTML实体(`HTMLEntity`)

## • `<icon>`组件

`<icon>`组件用于实现图标，语法结构是：

```HTML

<icon type="图标类型" size="图标尺寸" color="颜色"></icon>

```

> 图标类型包括：
>
> `success`，表示成功
>
> `warn`，表示警告
>
> `waitng`表示等待
>
> `clear`表示清除

## • `<progress>`组件