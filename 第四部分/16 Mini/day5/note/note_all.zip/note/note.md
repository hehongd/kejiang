# 微信小程序 - `Unit5`

# 1.页面事件

## 1.1 页面事件列表

页面事件存储在`page.js`中

```javascript

Page({
	onPullDownRefresh(){
        //向下拉刷新
    },
    onReachBottom(){
        //页面上拉触底事件
    },
    onPageScroll(){
        //页面滚动事件
    },
    onShareAppMessage(){
        //转发事件
    }
})


```

## 1.2 影片排行榜的实现

•  初始情况下要发送异步请求来获取前`10`条数据，示例代码如下：

```javascript

onLoad: function (options) {
    wx.request({
        url: 'https://api.douban.com/v2/movie/top250?apikey=0df993c66c0c636e29ecbb5344252a4a&start=0&count=10',
        method:'get',
        header:{
            'content-type':'application/x-www-form-urlencoded'
        },
        success:res=>{
            console.log(res.data);
            this.setData({
                movies:res.data.subjects
            })
        }
    })
}

```

得到数据后，在`WXML` 中进行遍历输出，示例代码如下：

```html

<view class="item" wx:for="{{movies}}" wx:key="index">
    <image src="{{item.images.large}}" class="poster"></image>
    <view class="meta">
        <view class="title">{{item.title}}</view>
        <view class="subTitle">{{item.original_title}}({{item.year}})</view>
        <view class="directors">{{item.directors[0].name}}</view>
    </view>
    <view class="rating">
        <text>{{item.rating.average}}</text>
    </view>
</view>

```

•  现在需要完成滚动到页面底部时，继续加载更多的数据，而根据之前学习过的`offset`参数的计算公式 -- `offset = (当前页码 - 1) * 每页显示的记录数` 来看，现在必须指定的当前页码，而且其值在页面滚动到底部后进行累加的操作，所以必须在`data`中声明变量，示例代码如下：

```javascript

Page({
	data:{
		//表示当前页码的初始值
		page:1
	}
})

```

而且在当滚动到页面底部时，进行累加操作，所以：

```javascript

let page = this.data.page;
//页码累加
page++; 
this.setData({
    page:page
});

```

另外，因为豆瓣电影`API`中的`start`参数从0开始编号，所以还必须根据当前的页码来计算`start`参数值，所以：

```javascript

let start = (page-1) * this.pagesize;

```

现在已经计算出`start`的参数值，而且页码也完成了累加操作，所以现在可以发送异步请求了，此时`page.js`中`onReachBottom`事件函数的示例代码如下：

```javascript

onReachBottom: function () {

    //获取当前的页码
    let page = this.data.page;

    //页码累加
    page++;

    //根据当前的页码来计算偏移值
    let start = (page - 1) * this.data.pagesize;


    //发送异步请求

    wx.request({
        url: 'https://api.douban.com/v2/movie/top250?apikey=0df993c66c0c636e29ecbb5344252a4a&start=' + start + '&count=' + this.data.pagesize,
        method: 'GET',
        header: {
            'content-type': 'application/x-www-form-urlencoded'
        },
        success: res => {
            console.log(res.data.subjects);
        }
    });

    this.setData({
        page: page
    });

}


```

## 1.3 微信小程序的`API`

• `wx.showToast`()

`wx.showToast()`方法用于显示短消息提示框，其语法结构是：

```javascript

wx.showToast({
	title:"显示的标题信息",
	icon:"显示的图标(success|loading|none)",
	image:"显示的图像(优先级高于icon)",
	duration:显示的时长(毫秒),
	success:(res)=>{
		//...
	},
	err:(err)=>{
		//...
	},
	complete:()=>{
		//...
	}    
})

```

• wx.`hideToast()`

`wx.hideToast()`方法用于隐藏短消息提示框，其语法结构是：

```javascript

wx.hideToast({
	success:(res)=>{
		//...
	},
	err:(err)=>{
		//...
	},
	complete:()=>{
		//...
	}
})

```

• `wx.showLoading()`

`wx.showLoading()`方法用于显示加载提示框，其语法结构是：

```javascript

wx.showLoading({
	title:"显示的标题信息",
	mask:是否显示遮置层,
    success:(res)=>{
		//...
	},
	err:(err)=>{
		//...
	},
	complete:()=>{
		//...
	}
})

```

> `wx.showLoading()`必须主动调用 `wx.hideLoading()`方法才能关闭

• `wx.hideLoading()`

`wx.hideLoading()`方法用于关闭加载提示框，其语法结构是：

```javascript

wx.hideLoading({
	success:(res)=>{
		//...
	},
	err:(err)=>{
		//...
	},
	complete:()=>{
		//...
	}
})

```

• `getApp()`函数

`getApp()`函数用于获取微信小程序应用对象，在`app.js`(微信小程序入口脚本文件)中存在`globalData`属性，用于存储全局的变量。示例代码如下：

```javascript

//app.js
App({
    onLaunch(){
        //...
    },
    onShow(){
        //...
    },
    globalData:{
        //存储全局变量
        url:'https://www.baidu.com'
    }
})

```

其他页面使用时可以通过以下方法实现，示例代码如下：

```javascript
const app = getApp();
Page({
	onLoad(options){
		console.log(app.globalData.url);
	},
    onShow(){
        console.log(getApp().globalData.url);
    }
})


```

# 2.`WXS`

`WXS（WeiXin Script）`是小程序的一套脚本语言

`WXS`中的数据类型、流程控制语句、基本对象（ `string`、`Math`、`Boolean`、`Number`等）参见`ES5`

`WXS`模块

`wxs`代码书写到以`.wxs`为扩展名的文件内，每个`wxs`文件是一个单独的模块，可通过`module exports`导出模块，从而暴露出一些方法或属性供用户使用。示例代码如下：

```javascript

function fun1(){
    return 'fun1';
}

function fun2(){
    return 'fun2';
}

module.exports = {
    plus:fun1,
    minus:fun2
}

```

在`page.wxml`中通过`<wxs>`标签调用外部的脚本文件，示例代码如下:

```html

<wxs src="WXS脚本文件的路径" module="模块名称"></wxs>

```

> `WXS`脚本文件的路径必须为相对路径
>
> `module`属性必须指定，但必须为合法的变量名称(严格的来说是对象的名称)

