# 微信小程序 -- `Unit06`

# 1.微信小程序云开发

## 1.1 概述

微信小程序云开发的类型有：

- 云存储，类似于网盘，可以存储任意的图像、音像、视频等文件。
- 云数据库，是一个专门为微信小程序提供的`JSON`类型的数据库。
- 云函数，实现更为复杂的服务器扩展功能。

## 1.2 创建云开发项目

![image-20200724092604960](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200724092604960.png)

## 1.3  开通云服务

A.单击工具栏中的"云开发"按钮

![image-20200724093136195](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200724093136195.png)

B.

> 每个微信小程序最多只能开通两个云服务
>
> 微信小程序只能使用自己关联的云服务，协议前缀为 `cloud://`
>
> 云服务一旦指定，无法直接进行修改（只能通过填写工单实现）

# 2.云存储

云存储可想像成网盘，用于存储微小程序中使用的图像、音频、视频等文件。云存储中的文件管理可以通过两种方式实现管理：

A.通过云开发控制台实现

B.通过脚本实现

## 2.1 通过云开发控制台实现

A. 通过云开发控制台上传文件 -- 如图片文件

![image-20200724103133862](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200724103133862.png)

B.在`page.xwml`中书写相应的组件 -- 如`<image>`组件，并且修改`src`属性值为上传文件的`file ID`，示例代码如下：

![image-20200724103418960](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200724103418960.png)

```html

<image src="cloud://web-mx-wuhua-gn0n3.7765-web-mx-wuhua-gn0n3-1301465321/0ec567a7f5fd1feb.jpg"></image>

```

## 2.2 通过脚本实现

## · `wx.chooseImage()`

`wx.chooseImage()`方法用于实现从本地相册选择图片或使用相机拍照，其语法结构是：

```javascript

wx.chooseImage({
	count:最多选取的图片数量(整数类型,默认为9),
    //Album,相册
    //Camera,相机
	sourceType:图片源的类型(Array类型,['album', 'camera']),
	success:(res)=>{
		//...
	}
})

```

> `success`回调函数的返回值包括：
>
> `tempFilePaths`，返回由上传文件临时名称组成的字符串数组，形如：
>
> ```javascript
> 
> tempFilePaths:[ "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.VkXLh4NRd8Mv8baad233fb0fc075596bc3ffcaedbe26.jpg",
>                "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.GwLaZnjRGt8M518c26c29502ac9c279ab2fa9d2b2193.jpg",
>                "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.4TbnY4FIpkxPcb313f391f36f2de7af69f2.jpg"
> ]
> 
> ```
>
> `tempFiles`，返回由上传文件临时名称组成的对象数组，形如：
>
> ```javascript
> 
> tempFiles:[
>     {
>         path: "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.VkXLh4NRd8Mv8baad233fb0fc075596bc3ffcaedbe26.jpg",
>         size: 99396
>     },{
>         path: "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.GwLaZnjRGt8M518c26c29502ac9c279ab2fa9d2b2193.jpg",
>     },{
>         path: "http://tmp/wx032d58018bcfc0c2.o6zAJs1Wk6dVHlKPlMHO5VbQ_vUw.4TbnY4FIpkxPcb313f391f36f2de7af69f2d64c26828.jpg"
>         size: 175410
>     }
> ]
> 
> ```

### · `wx.cloud.uploadFile()`

`wx.cloud.uploadFile()`方法用于实现将本地资源上传至云存储空间，其语法结构是：

```javascript
wx.cloud.uploadFile({
	filePath:"要上传文件资源的路径",
    cloudPath:"云存储的路径",
    success:res=>{
        //...
    }
})
```

