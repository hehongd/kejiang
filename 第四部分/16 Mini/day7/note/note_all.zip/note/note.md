

# 微信小程序 - `Unit7`

# 1.云数据库

> 注意基础库的版本

## · 集合对象实例

## · `db.command`

- 逻辑运算符
- `and()`方法
- `or()`方法
- `not()`方法

##  · `Aggregate`对象

`Aggregate`对象为聚合对象，通过`Collection`对象的`aggregate()`方法可以返回该对象，包含的方法有：

`group`、`end`、`limit`等

而在聚合操作时，需要引用聚合操作的运算符，但是聚合操作运算符需要通过`db.command.aggregate`属性才能返回。

## · `AggregateCommand`

数据库聚合操作符，通过 `db.command.aggregate` 获取

- `max()`
- `min()`
- `sum()`
- `avg()`

## · 更新记录

更新记录通过`Collection`对象的`update() `方法实现，语法结构是：

```javascript

Collection.where({
	....
}).update({
	data:{
		...
	}
})

```

> update() 方法在基础库版本为2.12中必须指定条件表达式
>
> 注意集合的权限
>
> 记录的更新可通过`Collection`对象的`doc()`方法返回的`Document` 对象的`update()`方法进行更新，形如：
>
> ```
> 
> db.collection('comments').doc('9bf625a55f1a9bbc005eeae019c6664a').update({....})
> 
> ```
>
> `doc()`方法只接收`_id`的字段值

## · 删除记录

删除记录可以通过`Collection`对象的`remove()`方法实现，在该方法中必须带有`where()`条件，语法结构是：

```

Collection.where({
	...
}).remove()

```

> 注意集合的权限
>
> 记录的删除可通过`Collection`对象的`doc()`方法返回的`Document` 对象的`remove()`方法进行更新，形如：
>
> ```
> 
> db.collection('comments').doc('9bf625a55f1a9bbc005eeae019c6664a').remove()
> 
> ```
>
> 

## · 豆瓣电影的影片评论

1.只能对特定的记录在云数据库中添加影片评论信息：

| 影片名称         | 影片ID   |
| ---------------- | -------- |
| 多力特的奇幻冒险 | 27000981 |
| 喋血战士         | 4830483  |
| 第一次离别       | 30337172 |
| 璀璨薪火3D       | 27591270 |

2.在云数据库中每个影片的评论信息的结构规定如下：

```
{
	"_id":自动生成,
	"_openid":自己的OPENID,
	"movieid":电影的ID,
	"writer":{
		"name":"评论人的姓名",
		"nickname":"评论人的昵称"
	},
	"content":"评论的内容"
}

```

3.在云开发控制台中创建名称为`douban`的集合，并且导入数据

![image-20200725152910667](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725152910667.png)

4.在查看影片详情时显示当前影片的评论信息

编辑`pages/detail/detail.js`

在访问某一个影片的详细信息时，除要显示影片的标题、图像、导演等信息后，还要显示当前影片的评论信息，那就意味着在`detail.js`的`onLoad()`钩子函数中还要获取云数据库中的相关影片的详论信息。示例代码如下：

```javascript

Page({
    onLoad(options){
        //获取URL地址栏中的参数
        let id = options.id;
        //从云数据库中获取当前影片的评论信息
        let db = wx.cloud.database();
        db.collection('douban').field({
            content:true,
            'writer.nickname':true
        }).where({
            'movieid':db.command.eq(id)
        }).get({
            success:res=>{
                console.log(res);
            }
        });
    }
})

```

此时可能的运行效果如下：

![image-20200725160029357](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725160029357.png)

根本原因是没有启动云服务(因为文件覆盖的原因造成的) -- 解决方案是：

在`app.js`的`onLaunch()`钩子函数中添加以下代码：

```javascript

wx.cloud.init({
    //云环境ID,云环境ID,云环境ID!!!
	env:"云环境ID",
	//是否启动跟踪用户(可以云开发控制台的运营分析中查看)
	traceUser:true
});


```

![image-20200725160843674](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725160843674.png)

当修改成功后，再单击某一部影片，此时控制台的输出结果如下：

![image-20200725161203142](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725161203142.png)

此时证明已可获取到当前影片的评论信息，但是现在的问题是：应该将影片的评论信息显示在`WXML`的页面组件中，所以，先需要在`data`中声明变量用于存储云数据库返回的评论信息，接着在获取到云数据库的数据后，再将获取到数据的响应到刚刚声明的变量中，示例代码如下：

```javascript

Page({
    data:{
        //存储评论信息
        comments:[]
    },
    onLoad(options){
        //获取URL地址栏中的参数
        let id = options.id;
        //从云数据库中获取当前影片的评论信息
        let db = wx.cloud.database();
        db.collection('douban').field({
            content:true,
            'writer.nickname':true
        }).where({
            movieid:db.command.eq(id)
        }).get({
            success:res=>{
                this.setData({
                    comments:res.data
                })
            }
        });
    }
})

```

最后在`detail.wxml`中进行遍历操作，示例代码如下：

```html

<view wx:for="{{comments}}" wx:key="index"> 
  <text style="display:block;margin:20rpx 0;">
    {{item.writer.nickname}}:{{item.content}}
  </text>
</view>

```

# 2.云函数

云函数是腾讯云提供的、针对微信小程序的自定义函数。

## 2.1 创建云函数

A.鼠标右键`"CloudFunctions"`然后在弹出的快捷菜单中选择"新建Node.js云函数"

![image-20200725165649762](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725165649762.png)

B.在云函数目录下的`index.js`中根据业务需要完成自定义函数的封装，示例代码如下：

```javascript

// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
//现在我们通过这个云函数来实现简单的加法
//其中第一个参数,叫a1
//第二个参数叫,a2
exports.main = async (param) => {
  //所谓的event是所有形参组成的对象!!!
  return param.a1 + param.a2;
}

```

> `param`是自定义函数中所有的参数形成的对象
>
> 在上述代码中的`a1`和`a2`代表形参的名称，类似于 `function test(a1,a2)`

C.在要部署的云函数上单击鼠标右键，从弹出的快捷菜单中选择“上传并部署:云端安装依赖(不上传`node_modules`)”

![image-20200725171355409](https://web1910-1301510526.cos.ap-beijing.myqcloud.com/image-20200725171355409.png)

D.在微信小程序客户端调用云函数，其语法结构是：

```javascript

wx.cloud.callFunction({
   	name:"云函数的名称" ,
    data:{
        //云函数的参数
    },
    success:res=>{
        //....
    }
})

```

