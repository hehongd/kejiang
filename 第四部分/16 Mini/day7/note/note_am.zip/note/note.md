

# 微信小程序 - `Unit7`

# 1.云数据库

> 注意基础库的版本

## · 集合对象实例

## · `db.command`

- 逻辑运算符
- `and()`方法
- `or()`方法
- `not()`方法

##  · `Aggregate`对象

`Aggregate`对象为聚合对象，通过`Collection`对象的`aggregate()`方法可以返回该对象，包含的方法有：

`group`、`end`、`limit`等

而在聚合操作时，需要引用聚合操作的运算符，但是聚合操作运算符需要通过`db.command.aggregate`属性才能返回。

## · `AggregateCommand`

数据库聚合操作符，通过 `db.command.aggregate` 获取

- `max()`
- `min()`
- `sum()`
- `avg()`

## · 更新记录

更新记录通过`Collection`对象的`update() `方法实现，语法结构是：

```javascript

Collection.where({
	....
}).update({
	data:{
		...
	}
})

```

> update() 方法在基础库版本为2.12中必须指定条件表达式
>
> 注意集合的权限





