// pages/test/test.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
     images:[
      'https://k.sinaimg.cn/n/news/transform/310/w710h400/20200718/75c8-iwpcxkr8565396.jpg/w710h340z1l1t1995.jpg',
      'https://k.sinaimg.cn/n/news/transform/310/w710h400/20200718/ec65-iwpcxkr8556864.jpg/w710h340z1l1t1e5b.jpg',
      'https://k.sinaimg.cn/n/news/transform/310/w710h400/20200718/0464-iwpcxkr8549561.jpg/w710h340z1l1t1b35.jpg',
      'https://k.sinaimg.cn/n/news/transform/310/w710h400/20200718/f31d-iwpcxkr8566236.jpg/w710h340z1l1t1bfa.jpg',
      'https://k.sinaimg.cn/n/news/transform/310/w710h400/20200718/eafa-iwpcxkr8564751.jpg/w710h340z1l1t141a.jpg',
     ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})