import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work01',
  templateUrl: './work01.component.html',
  styleUrls: ['./work01.component.css'],
})
export class Work01Component implements OnInit {
  // 网络请求 必须手动加载 模块
  constructor(public http: HttpClient) {}

  // range(5) -> [1,2,3,4,5]
  range(num: number) {
    let arr = [];

    for (let i = 1; i <= num; i++) {
      arr.push(i);
    }

    return arr;
  }

  res: News; //属性才能在 html 中使用. 类似 vue 的 data

  ngOnInit(): void {
    this.getData(1);
  }

  // 函数的 复用 特征: 可以重复使用
  getData(pno: number) {
    let url =
      'http://101.96.128.94:9999/mfresh/data/news_select.php?pageNum=' + pno;

    this.http.get(url).subscribe((res: News) => {
      console.log(res);

      this.res = res;
    });
  }
}

////////////////////////////////////////////////
/////////////// Ts: 静态类型特征 ////////////////
///////////////////////////////////////////////
interface News {
  data: NewsData[]; //数组里的元素为 NewsData 类型
  pageCount: number;
  pageNum: number;
  pageSize: number;
  totalRecord: number;
}

interface NewsData {
  content: string;
  nid: string;
  pubTime: string;
  title: string;
}
