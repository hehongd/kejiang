import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
export class Myc02Component implements OnInit {
  // 接收事件的属性
  // input 向内传递   output 向外传递
  // EventEmitter: 事件触发器.  传入的show方法 保存在这个对象里
  // 传入的 show()  就会存放在 msgEvent 对象里
  @Output() msgEvent = new EventEmitter();

  constructor() {}

  ngOnInit(): void {}
}
