import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
})
export class Myc01Component implements OnInit {
  // 声明 要接受 name 属性
  // vue中: props: ['name']
  // @Input(): 固定标识, 代表 name 属性是外来的
  @Input() name: string;
  @Input() age: number;

  // object 相当于 {}  空对象
  // 对象类型  要自己声明
  @Input() boss: Boss;

  constructor() {
    this.boss.name;
  }

  ngOnInit(): void {}
}

///////////////////////////////////
//////////////对象类型要 自定义/////
interface Boss {
  name: string;
  age: number;
}
