import { Component, ViewChild } from '@angular/core';
import { Myc03Component } from './myc03/myc03.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // 关联变量 与 子元素
  // ViewChild(): 查找到唯一标识对应的元素绑定给后面的变量上
  @ViewChild('mm3') suibian: Myc03Component; //补类型, 有代码提示

  test() {
    console.log(this.suibian);
    this.suibian.age += 2;

    this.suibian.show();
  }

  title = 'ngpro';

  show(msg) {
    console.log(msg);
  }
}
