import { Component } from "@angular/core";

import { Platform } from "@ionic/angular";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { HttpClient } from "@angular/common/http";
import { url } from "inspector";

@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.scss"],
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private http: HttpClient
  ) {
    this.initializeApp();
  }

  res: MeiTu;

  // 下拉刷新
  doRefresh(event) {
    let url = "https://api.apiopen.top/getImages?page=7";

    this.http.get(url).subscribe((res: MeiTu) => {
      console.log(res);
      // 新的数据 覆盖 旧的
      this.res = res;

      this.page = 7; //页数回归初值
      event.target.complete(); // 让下拉刷新状态结束
    });
  }

  // 触底 加载更多触发
  page = 7; //当前页

  loadData(event) {
    let url = "https://api.apiopen.top/getImages?page=" + (this.page + 1);

    this.http.get(url).subscribe((res: MeiTu) => {
      console.log(res);
      // 合并数据: 旧数据 和 新数据 合并
      res.result = this.res.result.concat(res.result);

      this.res = res;
      // 告诉组件: 本次加载更多操作已结束.  这样组件才可以准备下一次
      event.target.complete();

      this.page++; //页数更新
    });
  }

  ngOnInit(): void {
    let url = "https://api.apiopen.top/getImages?page=7";

    this.http.get(url).subscribe((res: MeiTu) => {
      console.log(res);

      this.res = res;
    });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}

////////////////////////////////////////
interface MeiTu {
  code: number;
  message: string;
  result: Result[];
}

interface Result {
  id: number;
  time: string;
  img: string;
}
