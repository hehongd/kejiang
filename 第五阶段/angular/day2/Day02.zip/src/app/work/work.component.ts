import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work',
  templateUrl: './work.component.html',
  styleUrls: ['./work.component.css'],
})
export class WorkComponent implements OnInit {
  // 运行期间会变化的量, 保存成变量
  name = 'iPhone';
  price = 8999;
  count = 4; //成员属性

  doMinus() {
    // this: 面向对象的关键词, 代表当前对象
    // 本质是从格式上区分 成员属性 和 局部变量
    // let count = 5; //局部变量

    this.count--;
  }

  constructor() {}

  ngOnInit(): void {}
}
