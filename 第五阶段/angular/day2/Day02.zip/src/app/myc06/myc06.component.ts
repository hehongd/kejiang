import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc06',
  templateUrl: './myc06.component.html',
  styleUrls: ['./myc06.component.css'],
})
export class Myc06Component implements OnInit {
  count = 1;

  constructor() {
    // 构造方法: 严格说不算生命周期.
    // 面向对象中, 对象实例化时 触发
    console.log('constructor: 构造方法');
  }

  ngOnInit(): void {
    // 相当于 vue 的 created
    console.log('ngOnInit: 开始创建');
  }

  // 更新 分为: UI的更新 和 数据的更新
  ngAfterContentInit(): void {
    // 相当于 mounted 挂载
    console.log('ngAfterContentInit: 数据初始化完毕后');
  }

  ngAfterViewInit(): void {
    // 相当于 mounted 挂载
    console.log('ngAfterViewInit: UI初始化完毕后');
  }

  ngAfterContentChecked(): void {
    console.log('ngAfterContentChecked: 数据变更');
  }

  ngAfterViewChecked(): void {
    console.log('ngAfterViewChecked: UI变更后');
  }

  ngOnDestroy(): void {
    console.log('ngOnDestroy: 将要销毁');
  }
}
