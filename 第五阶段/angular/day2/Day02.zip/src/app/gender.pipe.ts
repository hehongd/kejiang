import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gender',
})
export class GenderPipe implements PipeTransform {
  // {{ 0 | gender }}: 此语法本质是语法糖, 执行时会编译为:
  // new GenderPipe().transform(0)
  transform(value: number) {
    // TS语法, 类型声明.   参数: 类型名
    // if (value == 0) return '女';
    // if (value == 1) return '男';
    // if (value == 2) return '保密';

    // 数组[下标]
    return ['男', '女', '保密'][value];
  }
}

/**
 * 要学会从 代码格式上 判断出数据类型
 *
 * ab():  ab是什么   函数
 * ab()[0]:  ab() 的返回值是什么?  数组
 * ab()(): ab() 的返回值是什么? 函数
 * ab()().show()[2]
 */
