import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appGreen]',
})
export class GreenDirective {
  constructor(e: ElementRef) {
    console.log(e);

    e.nativeElement.style.color = 'green';
    e.nativeElement.style.border = '1px solid green';
    e.nativeElement.style.borderRadius = '4px';
    e.nativeElement.style.display = 'inline-block';
    e.nativeElement.style.padding = '4px';
  }
}
