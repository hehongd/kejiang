import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pow',
})
export class PowPipe implements PipeTransform {
  // {{ 2 | pow: 10}}
  transform(value: number, exp: number) {
    // **: 次幂运算符  2**10  就是 2的10次方
    return value ** exp;
  }
}
