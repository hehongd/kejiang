import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WorkComponent } from './work/work.component';
import { FormsModule } from '@angular/forms';
import { Myc01Component } from './myc01/myc01.component';
import { Myc02Component } from './myc02/myc02.component';
import { Myc03Component } from './myc03/myc03.component';
import { Myc04Component } from './myc04/myc04.component';
import { GenderPipe } from './gender.pipe';
import { PfPipe } from './pf.pipe';
import { PowPipe } from './pow.pipe';
import { Myc05Component } from './myc05/myc05.component';
import { HideDirective } from './hide.directive';
import { GreenDirective } from './green.directive';
import { FocusDirective } from './focus.directive';
import { Myc06Component } from './myc06/myc06.component';

@NgModule({
  declarations: [AppComponent, WorkComponent, Myc01Component, Myc02Component, Myc03Component, Myc04Component, GenderPipe, PfPipe, PowPipe, Myc05Component, HideDirective, GreenDirective, FocusDirective, Myc06Component],
  // 加载模块后, 必!须!重!启! 服务器, 才能生效!!
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
