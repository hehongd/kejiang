import { PfPipe } from './pf.pipe';

describe('PfPipe', () => {
  it('create an instance', () => {
    const pipe = new PfPipe();
    expect(pipe).toBeTruthy();
  });
});
