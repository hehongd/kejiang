import { GreenDirective } from './green.directive';

describe('GreenDirective', () => {
  it('should create an instance', () => {
    const directive = new GreenDirective();
    expect(directive).toBeTruthy();
  });
});
