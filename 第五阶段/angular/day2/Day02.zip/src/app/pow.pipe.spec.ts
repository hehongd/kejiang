import { PowPipe } from './pow.pipe';

describe('PowPipe', () => {
  it('create an instance', () => {
    const pipe = new PowPipe();
    expect(pipe).toBeTruthy();
  });
});
