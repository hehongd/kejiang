import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appHide]',
})
export class HideDirective {
  // 指令初始化时, 参数固定为 所在的 元素
  // 构造函数: 对象初始化时触发;
  constructor(e: ElementRef) {
    console.log(e);

    e.nativeElement.style.display = 'none';
  }
}
