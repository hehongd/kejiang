import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
export class Myc02Component implements OnInit {
  names = ['html5', 'axios', 'ajax', 'jsonp', 'cors', 'proxy'];

  emps = [
    { name: '东东', age: 33, phone: '13877889988' },
    { name: '然然', age: 34, phone: '13877779988' },
    { name: '亮亮', age: 29, phone: '13877239988' },
    { name: '小新', age: 28, phone: '13877549988' },
  ];

  // 自制方法: 4 -> [1,2,3,4]
  range(num) {
    let arr = [];

    for (let i = 1; i <= num; i++) {
      arr.push(i);
    }

    return arr;
  }

  constructor() {}

  ngOnInit(): void {}
}
