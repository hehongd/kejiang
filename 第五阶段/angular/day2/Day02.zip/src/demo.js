// JavaScript 没有静态类型分析功能, 只有动态类型分析功能!
// 动态: 运行时
// 静态: 不运行时

// vscode 在阅读此行代码时, 只知道 变量名是a
function show(abc){
  return abc.toUpperCase()
}

show(123)