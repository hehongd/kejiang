// typescript 是 JavaScript 的升级版本:  把很多 Java 的语言特性 添加到了 JavaScript 中
// 由微软公司进行维护

// 最重要的特征: 静态类型分析特征

// 语言排行榜 TIOBE 中, 除了JS 都有 静态类型分析功能;
// 变量名:类型名
// :类型名  是写给 IDE 开发软件看的, 即 vscode
function show(abc: string) {
  // vscode: 读代码时  就知道 变量abc 是个 string 类型
  return abc.toUpperCase();
}

show(123);

/**
 * 静态类型分析功能:  就是对程序员友好的特性
 * 1. 变量使用有提示
 * 2. 预警: 代码不用运行 也能预判错误
 *
 * 有了这两个特征: 有效降低 bug 的出现
 */
