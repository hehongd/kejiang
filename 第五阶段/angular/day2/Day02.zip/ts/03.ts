// 对象类型

let boss = {
  name: "wenhua",
  age: 33,
  gender: 1,
  married: true,
};

// 声明对象类型的范式:
// interface: 接口.  新的关键词 与 class function 一样.  用于声明类型
interface Boss {
  // 模板中规定:  要哪些属性, 属性要什么类型
  name: string;
  age: number;
  gender: number;
  married: boolean;
}

// 一个对象 是 Boss 类型:  系统会自动检测 对象是否符合 模板要求
let dong: Boss = {
  name: "东东",
  age: 44,
  gender: 1,
  married: true,
};

// 雇员IT  ---  模板
interface IT_Employee {
  name: string;
  age: number;
  skills: string[]; //数组类型, 其中都是字符串
}

let youyu: IT_Employee = {
  name: "鱿鱼须",
  age: 26,
  skills: ["html", "css", "js", "vue", "react"],
};
