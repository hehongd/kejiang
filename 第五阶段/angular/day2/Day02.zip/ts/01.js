// 特征:  静态类型分析
// 参数名:类型
// :类型 是给 vscode 看.  vscode 就知道参数的类型, 进而提供两大功能:
// 1. 代码提示
// 2. 报错预警
function show(name) {
    // 代码提示
    console.log(name.toUpperCase());
}
//报错预警
show("mike");
/**
 * 想要运行, 则必须转化成 JS 文件
 *
 * 转化方式:
 * 1. 安装成功: tsc 01.ts
 * 2. 安装失败: npx tsc 01.ts
 */
