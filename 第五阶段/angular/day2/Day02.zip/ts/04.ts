// 面向对象的 访问控制词:  可以让对象的属性 更加安全

/**
 * public: 公开的 --  类外 类内 子类
 * protected: 保护的 -- 类内 子类
 * private: 私有的 -- 类内
 */

class RanGe {
  // 默认不写关键词, 则是 public 代表公开: 类外可以
  public name = "然然";
  // protected: 保护的.  类外无法访问
  protected money = "999元";
  protected wifes = ["貂蝉", "小乔", "贾玲"];
  // 私有: 只有类内可以使用,  子类也不行
  private avi = "然哥珍藏多年的 小电影";

  show() {
    this.avi; //类内可以访问私有
  }
}

// 然哥的儿子
class Son extends RanGe {
  show() {
    // this.avi;
  }
}

// 在 类外 访问类中的属性
let rg = new RanGe();
// rg.money; //类外无法访问 保护属性
