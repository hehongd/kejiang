// 类型声明 详细介绍

class Demo {
  // 完整格式:  变量名: 类型名 = 值;

  name: string = "lucy"; //字符串
  age: number; //数字
  married: boolean; // 布尔类型 true / false

  xyz: any; //any 任意类型. 为默认值

  // 自定义混合类型
  abc: number | boolean; // 数字 或 布尔

  // 数组: 两种写法, 都代表  数组中 都是 string 类型元素
  names: Array<string>;
  items: string[];

  // 规定数组中每个值的类型 及 数量
  emp: [string, number, boolean];

  show() {
    this.emp = ["dongdong", 33, true];
    this.emp = ["dongdong", 33];
    this.emp = ["dongdong", true];

    // this.names = ["mike", "lucy", 123, true];
    // this.items = ["mike", "lucy", 123, true];

    this.abc = 123;
    this.abc = true;
    // this.abc = "mike";

    this.xyz = 12;
    this.xyz = "mike";
  }
}
