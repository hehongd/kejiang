import { Component } from "@angular/core";

import { Platform } from "@ionic/angular";
import { SplashScreen } from "@ionic-native/splash-screen/ngx";
import { StatusBar } from "@ionic-native/status-bar/ngx";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.scss"],
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private http: HttpClient
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  res: News;

  page = 1; //初始页

  doRefresh(event) {
    let url = "https://api.apiopen.top/getWangYiNews?page=1";

    this.http.get(url).subscribe((res: News) => {
      console.log(res);
      this.res = res;

      event.target.complete();
      this.page = 1;
    });
  }

  loadData(event) {
    let url = "https://api.apiopen.top/getWangYiNews?page=" + (this.page + 1);

    this.http.get(url).subscribe((res: News) => {
      console.log(res);
      // 新旧数据合并
      res.result = this.res.result.concat(res.result);
      this.res = res;

      this.page++; //更新页数
      event.target.complete(); // 声明本次加载更多操作已完毕
    });
  }

  ngOnInit(): void {
    let url = "https://api.apiopen.top/getWangYiNews?page=1";

    this.http.get(url).subscribe((res: News) => {
      console.log(res);

      this.res = res;
    });
  }
}

///////////////////////////////////////
//////////// 类型声明 /////////////////
/////////////////////////////////////
interface News {
  code: number;
  message: string;
  result: NewsResult[];
}

interface NewsResult {
  image: string;
  passtime: string;
  path: string;
  title: string;
}
