import { Component, OnInit } from "@angular/core";
import { AlertController, NavController } from "@ionic/angular";

@Component({
  selector: "app-detail",
  templateUrl: "./detail.page.html",
  styleUrls: ["./detail.page.scss"],
})
export class DetailPage implements OnInit {
  // AlertController: 弹出框服务
  constructor(public router: NavController, public alertC: AlertController) {}

  goback() {
    this.router.back();
  }

  ngOnInit() {}

  onClick() {
    // alertC 与 axios 都是 Promise 制作的,
    // create(): 负责生成弹出框, 生成后会通过 then 执行下一步.  res 就是生成的弹出框
    // res.present(): 是 弹出提示框 的意思
    this.alertC
      .create({
        header: "标题",
        subHeader: "子标题",
        message: "具体内容",
        buttons: [
          "确定",
          "取消",
          // 通过{} 对象方式, 为按钮添加回调
          { text: "哈哈", handler: () => console.log("哈哈 按钮点击") },
        ],
      })
      .then((res) => res.present());
  }

  // 绑定搜索框, 实时获取搜索框的内容
  onSearchChange(event) {
    // console.log(event);
    let value = event.detail.value;
    console.log(value);
    // 搭配 搜索接口, 就可以 实时显示 搜索的数据
  }
}
