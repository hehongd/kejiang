import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { Tab05Page } from './tab05.page';

describe('Tab05Page', () => {
  let component: Tab05Page;
  let fixture: ComponentFixture<Tab05Page>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Tab05Page ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(Tab05Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
