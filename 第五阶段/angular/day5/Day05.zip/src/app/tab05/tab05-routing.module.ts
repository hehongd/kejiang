import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Tab05Page } from './tab05.page';

const routes: Routes = [
  {
    path: '',
    component: Tab05Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Tab05PageRoutingModule {}
