import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab05',
  templateUrl: './tab05.page.html',
  styleUrls: ['./tab05.page.scss'],
})
export class Tab05Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
