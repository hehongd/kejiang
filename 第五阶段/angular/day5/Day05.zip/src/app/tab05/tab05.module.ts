import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Tab05PageRoutingModule } from './tab05-routing.module';

import { Tab05Page } from './tab05.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Tab05PageRoutingModule
  ],
  declarations: [Tab05Page]
})
export class Tab05PageModule {}
