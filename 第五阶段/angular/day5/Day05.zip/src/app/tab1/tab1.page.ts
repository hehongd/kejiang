import { Component } from "@angular/core";
import { NavController } from "@ionic/angular";

@Component({
  selector: "app-tab1",
  templateUrl: "tab1.page.html",
  styleUrls: ["tab1.page.scss"],
})
export class Tab1Page {
  // 通过服务 实现编程式跳转
  constructor(public router: NavController) {}

  onClick() {
    // vue: this.$router.push()
    // 不带参数:
    // this.router.navigateForward("/tabs/tab3");
    // 带参数: [路径, 参数对象]
    this.router.navigateForward(["/tabs/tab2", { name: "dongdong", age: 22 }]);
  }
}
