import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-tab2",
  templateUrl: "tab2.page.html",
  styleUrls: ["tab2.page.scss"],
})
export class Tab2Page {
  /**
   * vue 接收路由参数 有 两种方式:
   * * this.$route.params.xxx
   * * 属性传参:  路由配置中要添加 props:true 的配置项,  就可以通过 props: ['xxx'] 接收参数
   */

  //  angular 通过 服务 接收参数
  constructor(public route: ActivatedRoute) {}

  ngOnInit(): void {
    console.log(this.route);
  }
}
