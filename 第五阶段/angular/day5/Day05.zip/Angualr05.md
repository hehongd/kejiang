# Angualr05

## 组件

### item

https://ionicframework.com/docs/api/item

![image-20201231103142936](Angualr05.assets/image-20201231103142936.png)

```html

<!-- item -->
<ion-app>
  <ion-header>
    <ion-toolbar>
      <ion-title>item</ion-title>
    </ion-toolbar>
  </ion-header>

  <ion-content>
    <!-- detail: 添加右箭头 -->
    <!-- button: 点击效果 -->
    <ion-item detail button>
      <ion-label>账号与安全</ion-label>
    </ion-item>

    <!-- i-item-avatar -->
    <ion-item>
      <!-- avatar: 内部图片变圆 -->
      <!-- slot: 插槽.  左右各有一个; start 和 end -->
      <ion-avatar slot="start">
        <img
          src="https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=2319772070,3114389419&fm=26&gp=0.jpg"
        />
      </ion-avatar>
      <!--  ion-label: 是一个带有 flex:1 写法的div. 宽度与剩余空间一致! -->
      <ion-label style="border: 2px solid red">
        <h2>sunny</h2>
        <p>小姐姐, 今天晚上一起开黑不? 我carry</p>
      </ion-label>
      <ion-badge color="danger">99+</ion-badge>
    </ion-item>

    <!-- i-item-group -->
    <ion-item-group>
      <ion-item-divider>
        <ion-label>A</ion-label>
      </ion-item-divider>

      <ion-item>
        <ion-label>阿宝</ion-label>
      </ion-item>
      <ion-item>
        <ion-label>阿涛</ion-label>
      </ion-item>

      <ion-item-divider>
        <ion-label>B</ion-label>
      </ion-item-divider>

      <ion-item>
        <ion-label>宝宝</ion-label>
      </ion-item>
      <ion-item>
        <ion-label>bin</ion-label>
      </ion-item>
    </ion-item-group>

    <!-- i-item-icon -->
    <ion-item>
      <ion-icon name="pizza" slot="start"></ion-icon>
      <ion-label>Pizza</ion-label>
    </ion-item>

    <!-- i-item-input -->
    <ion-item>
      <ion-label>姓名</ion-label>
      <!-- 输入框 -->
      <ion-input></ion-input>
    </ion-item>

    <ion-item>
      <ion-label>密码</ion-label>
      <!-- 输入框 -->
      <ion-input type="password"></ion-input>
    </ion-item>
  </ion-content>
</ion-app>

```



## 路由系统

生成带有路由系统的项目包:

```
ionic start tabsApp tabs
```

无法自己生成的同学, 按照下方操作:

* 到 FTP 的 18_angular 拿 tabs_src.zip
* 关闭vscode中所有打开的页面, 然后关闭vscode, 把项目包中的 src 改成 src1
* 把 tabs_src.zip 中的 src 文件夹 解压缩到 项目包中
* 重新打开vscode, 使用 `ionic s` 命令启动项目即可:  **注意关闭之前的服务**

### 配置标签栏

![image-20201231111823050](Angualr05.assets/image-20201231111823050.png)

### 生成页

> 组件按照用途 通常分为 两类, 例如在 vue 中
>
> views: 路由切换的 页面
>
> components: 存放 复用的 小组件

```
ionic g page 页面名
```

例如: `ionic g page tab4`

![image-20201231112435610](Angualr05.assets/image-20201231112435610.png)



练习: 新增 tab05

* 新建页面: `ionic g page tab05`
* 删除默认生成的全局路由配置: `app-routing.module.ts`
* 配置 tabs 路由, 添加05: `tabs-routing.module.ts`
* 配置 tabs 页面, 增加 商品 按钮, 对应 tab05: `tabs.page.html`



### 生成详情页

```
ionic g page detail
```



```typescript
import { Component, OnInit } from "@angular/core";
import { AlertController, NavController } from "@ionic/angular";

@Component({
  selector: "app-detail",
  templateUrl: "./detail.page.html",
  styleUrls: ["./detail.page.scss"],
})
export class DetailPage implements OnInit {
  // AlertController: 弹出框服务
  constructor(public router: NavController, public alertC: AlertController) {}

  goback() {
    this.router.back();
  }

  ngOnInit() {}

  onClick() {
    // alertC 与 axios 都是 Promise 制作的,
    // create(): 负责生成弹出框, 生成后会通过 then 执行下一步.  res 就是生成的弹出框
    // res.present(): 是 弹出提示框 的意思
    this.alertC
      .create({
        header: "标题",
        subHeader: "子标题",
        message: "具体内容",
        buttons: [
          "确定",
          "取消",
          // 通过{} 对象方式, 为按钮添加回调
          { text: "哈哈", handler: () => console.log("哈哈 按钮点击") },
        ],
      })
      .then((res) => res.present());
  }

  // 绑定搜索框, 实时获取搜索框的内容
  onSearchChange(event) {
    // console.log(event);
    let value = event.detail.value;
    console.log(value);
    // 搭配 搜索接口, 就可以 实时显示 搜索的数据
  }
}

```

```html
<ion-header>
  <ion-toolbar>
    <!-- 刷新页面: 路由记录会消失, 导致返回按钮 没有记录, 就不显示返回按钮 -->
    <!-- 必须点击跳转才能出 返回按钮 -->
    <!-- 默认: 返回按钮 -->
    <!-- i-back-button -->
    <!-- <ion-buttons slot="start">
      <ion-back-button></ion-back-button>
    </ion-buttons> -->

    <!-- 自定义按钮 -->
    <ion-button fill="clear" (click)="goback()" slot="start"> 返回 </ion-button>

    <ion-title>detail</ion-title>
  </ion-toolbar>
</ion-header>

<ion-content>
  <ion-button (click)="onClick()" expand="block" fill="clear" shape="round">
    Click me
  </ion-button>

  <!-- 搜索框 -->
  <!-- i-searchbar -->
  <ion-searchbar
    placeholder="商品名"
    inputmode="decimal"
    type="decimal"
    (ionChange)="onSearchChange($event)"
    [debounce]="250"
    showCancelButton="always"
  ></ion-searchbar>
</ion-content>

```

```typescript
import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-tab2",
  templateUrl: "tab2.page.html",
  styleUrls: ["tab2.page.scss"],
})
export class Tab2Page {
  /**
   * vue 接收路由参数 有 两种方式:
   * * this.$route.params.xxx
   * * 属性传参:  路由配置中要添加 props:true 的配置项,  就可以通过 props: ['xxx'] 接收参数
   */

  //  angular 通过 服务 接收参数
  constructor(public route: ActivatedRoute) {}

  ngOnInit(): void {
    console.log(this.route);
  }
}

```



## Angular收尾项目

目的: 锻炼学员的 **动手+动脑** 能力

资源: `18_Angualr/IonicProjectFiles.zip`



### 登录页面制作

* 需要一个全新的 带有 tabs 标签栏的 项目包
  * 可以自己生成, 也可以通过 替换 tabs_src 来实现:  
  * 详见今日文档
* 生成 tab4 
* 根据效果图, 配置 标签栏的 路由 和 样式
* 图标网站: https://ionicons.com
* 输入框: `ion-input`









## 放假时间要提前下载 React 的资源

大概 2G.

下周学 RN. 开发真正的手机端项目.  可以编译成 Apk 安装在手机上, 也可以发布到商店上线.

有安卓手机同学: 可以真机调试.    有iPhone的同学 可以换个安卓手机.

> 链接：https://pan.baidu.com/s/16jrKVaIZ_10H47t1rh4qBw 
> 提取码：lqc6 
> 复制这段内容后打开百度网盘手机App，操作更方便哦--来自百度网盘超级会员V4的分享





















