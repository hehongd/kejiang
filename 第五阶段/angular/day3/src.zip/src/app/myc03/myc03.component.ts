import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03',
  templateUrl: './myc03.component.html',
  styleUrls: ['./myc03.component.css'],
})
export class Myc03Component implements OnInit {
  // 声明依赖
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    // 请求的方式: 常见4种
    // GET POST PUT DELETE -- RestFul 服务器风格
    // GET查询数据. POST更新数据  PUT增 DELTE 删除
    // 最常见的是 GET POST
    let url = 'https://api.apiopen.top/getImages?page=7';
    // axios: this.axios.get(url).then(res=>{})

    // subscribe: 订阅 结果..  单词与axios不同, 原理一样
    this.http.get(url).subscribe((res: MeiTu) => {
      console.log(res);
      //res默认是 Object ,  不同类型赋值 vscode 会预警
      //要告诉vscode  res是 MeiTu 类型,  vscode 就不会报错
      this.res = res;
    });
  }

  // 属性才能在 html 中使用
  res: MeiTu;
}

////////////////////////////////////////////
////////////// 自定义返回值的数据类型 ////////
///////////////////////////////////////////
interface MeiTu {
  code: number;
  message: string;
  result: Result[]; // 数组类型 中的值 是 任意类型
}

interface Result {
  id: number;
  img: string;
  time: string;
}
