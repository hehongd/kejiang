import { Component, OnInit } from '@angular/core';
import { NameService } from '../name.service';
import { SkillService } from '../skill.service';

@Component({
  selector: 'app-myc02',
  templateUrl: './myc02.component.html',
  styleUrls: ['./myc02.component.css'],
})
export class Myc02Component implements OnInit {
  // skills = ['axios', 'vue', 'Vuex', 'jQuery', 'React'];

  // 语法糖写法
  // 固定格式:  权限词 变量名: 类型名
  // 此写法 就相当于之前的3步
  constructor(public suibian: SkillService, public nameS: NameService) {}

  // 属性: 可以在html中使用
  // suibian: SkillService;
  // nameS: NameService;

  // 依赖注入机制:  我们负责声明依赖, 系统负责自动注入
  // constructor(suibian: SkillService, nameS: NameService) {
  // 函数的参数: 局部变量--不能全局使用, 不能html中使用
  // this.suibian = suibian;

  // this.nameS = nameS;
  // }

  ngOnInit(): void {}
}

/**
 * 语法糖: 通过固定的语法 把一些较复杂的固定格式 进行简化操作
 *
 * if (xxx) { xxx } -> {}只有一行代码可以省略{}  =>  if (xxx) xxx
 *
 * (xxx)=>{}  只有1个参数, 则可以 xxx=>{}
 *
 * ()=> { return xxx; }  {}中只有一行return代码,   ()=>  xxx
 *
 * let obj = {name:'dongdong', age:33}
 * let name = obj.name; let age = obj.age;
 *
 * 语法糖: let {name,age} = obj;
 */
