import { AbsPipe } from './abs.pipe';

describe('AbsPipe', () => {
  it('create an instance', () => {
    const pipe = new AbsPipe();
    expect(pipe).toBeTruthy();
  });
});
