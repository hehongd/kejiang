import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css'],
})
export class Myc04Component implements OnInit {
  constructor(public http: HttpClient) {}

  res: WangYi;

  ngOnInit(): void {
    let url = 'https://api.apiopen.top/getWangYiNews';

    this.http.get(url).subscribe((res: WangYi) => {
      console.log(res);

      this.res = res;
    });
  }
}

///////////////////////////////////////
//////////// 声明返回值类型 ////////////
//////////////////////////////////////
interface WangYi {
  code: number;
  message: string;
  result: Result[]; // 数组类型, 其中的元素是 Result 类型
}

interface Result {
  image: string;
  passtime: string;
  path: string;
  title: string;
}
