import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc05',
  templateUrl: './myc05.component.html',
  styleUrls: ['./myc05.component.css'],
})
export class Myc05Component implements OnInit {
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    // http://capi.douyucdn.cn/api/v1/live
    // 域名部分 换成 /api
    let url = '/api/api/v1/live';

    this.http.get(url).subscribe((res) => {
      console.log(res);
    });
  }
}
