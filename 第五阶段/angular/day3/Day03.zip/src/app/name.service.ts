import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class NameService {
  names = ['mike', 'lucy', 'lily', 'john'];

  constructor() {}
}
