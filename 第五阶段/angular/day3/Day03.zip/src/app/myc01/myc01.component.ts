import { Component, OnInit } from '@angular/core';
import { SkillService } from '../skill.service';

@Component({
  selector: 'app-myc01',
  templateUrl: './myc01.component.html',
  styleUrls: ['./myc01.component.css'],
})
export class Myc01Component implements OnInit {
  // skills = ['axios', 'vue', 'Vuex', 'jQuery', 'React'];

  // 在 vue 中: this.$store.state.skills
  // 在 ng 中 , 服务的引入稍微麻烦

  // 变量名:类型名;  就有2个优点: 代码提示 和 报错预警
  abc: SkillService; //只有成员属性 才能在 html 中使用

  // 依赖声明: 当前组件实例化 必须传递一个 SkillService 类型的参数
  // 注入: 自动化操作-- 系统会自动实例化当前组件.  实例化时会传递 依赖的 类型的参数
  constructor(skillS: SkillService) {
    // 理论上 此处应该写 this.skillS = skillS; 比较合理
    // 此处写 abc 是为了防止有同学以为: 名字必须一样
    // 变量名是随意的, 但是应该有含义!
    // 变量名 应该有自注释效果 -- 看名字 能猜出大概作用!

    this.abc = skillS;

    // 类似vue中, 网络请求完毕时的  this.data = res.data.data; 操作
  }

  ngOnInit(): void {
    // this.abc
  }
}

/**
 * 程序中的 依赖注入 机制
 *
 * 生活中的例子:
 * 1. 超市门口的摇摇车: 标识  1元/次. 松松小朋友要玩, 则需要投币1元 才可以
 *    声明依赖: 1元/次   使用注入: 要玩就要投币1元
 *
 * 2. 新闻: 丈母娘说: 我家女儿20万彩礼...
 *    声明依赖: 20万   使用: 给20万
 */

//  声明依赖: 要一个 string 类型的 参数
function show(name: string) {
  console.log(name);
}

// 调用时： 就必须传递 string 类型的参数
show('mike');

class Demo {
  // 构造方法: 实例化时触发
  constructor(name: string) {}
  // 依赖注入机制: 声明要 string 类型的参数
}

// 使用时 就必须传递 string 类型的参数
new Demo('mike');
