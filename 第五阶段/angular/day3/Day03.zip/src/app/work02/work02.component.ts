import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work02',
  templateUrl: './work02.component.html',
  styleUrls: ['./work02.component.css'],
})
export class Work02Component implements OnInit {
  // 预定俗称的名称: assets 专门存放静态资源
  images = ['1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg'];

  // 序号: 当前显示的图片序号
  // current page: 当前页
  curP = 0;

  constructor() {}

  // 开始初始化: 类似于 vue 的 created 创建时. 页面还没创建好
  ngOnInit(): void {}

  // 电脑性能足够, 这两个周期的间隔很小..几乎忽略不计.  效果的差异不可感知.

  // 页面初始化完毕
  ngAfterViewInit(): void {
    // 此处更安全:   小概率事件-启动定时器之后, 2.5秒页面还没加载出来. 如果定时在 ngOnInit 里. 就会因为UI没初始化, 就修改值, 有风险.
    setInterval(() => {
      this.curP == this.images.length - 1 ? (this.curP = 0) : (this.curP += 1);
    }, 2500);
  }
}
