import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appDanger]',
})
export class DangerDirective {
  // e: 指令会把其所在的元素 作为参数传递到构造方法里
  constructor(e: ElementRef) {
    e.nativeElement.style.backgroundColor = 'red';
    e.nativeElement.style.color = 'white';
  }
}
