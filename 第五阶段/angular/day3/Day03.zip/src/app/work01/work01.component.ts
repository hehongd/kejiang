import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work01',
  templateUrl: './work01.component.html',
  styleUrls: ['./work01.component.css'],
})
export class Work01Component implements OnInit {
  items = ['吃饭', '睡觉', '打豆豆'];

  //输入框绑定
  todo = '';

  constructor() {}

  ngOnInit(): void {}
}
