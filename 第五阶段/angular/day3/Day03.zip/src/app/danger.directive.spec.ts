import { DangerDirective } from './danger.directive';

describe('DangerDirective', () => {
  it('should create an instance', () => {
    const directive = new DangerDirective();
    expect(directive).toBeTruthy();
  });
});
