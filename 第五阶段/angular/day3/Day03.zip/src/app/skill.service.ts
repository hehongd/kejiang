import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SkillService {
  // 想要在组件间分享的数据 和 方法 都可以放在这里
  skills = ['axios', 'vue', 'Vuex', 'jQuery', 'React'];

  show() {
    alert('我是 skill 服务');
  }

  constructor() {}
}
