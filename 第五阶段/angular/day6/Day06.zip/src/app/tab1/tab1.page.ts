import { HttpClient } from "@angular/common/http";
import { Component } from "@angular/core";

@Component({
  selector: "app-tab1",
  templateUrl: "tab1.page.html",
  styleUrls: ["tab1.page.scss"],
})
export class Tab1Page {
  // 依赖注入机制: 声明依赖
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    // 生命周期: 属于特殊的函数, 是系统提供的.  --- 函数中的 领导
    // 应该: 只负责安排任务 而 不做具体事情
    this.getData();
  }

  res: Result;

  getData() {
    let url = "http://101.96.128.94:9999/data/product/index.php";

    this.http.get(url).subscribe((res: Result) => {
      console.log(res);

      this.res = res;
    });
  }
}

///////////////////////////////////////
/////////// TS新增特性: 静态类型 ///////
interface Result {
  carouselItems: CarouselItem[];
  newArrivalItems: Item[];
  recommendedItems: Item[];
  topSaleItems: Item[];
}

interface CarouselItem {
  cid: string;
  href: string;
  img: string;
  title: string;
}

interface Item {
  details: string;
  href: string;
  pic: string;
  pid: string;
  price: string;
  title: string;
}
