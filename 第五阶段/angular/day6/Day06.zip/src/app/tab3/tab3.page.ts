import { HttpClient } from "@angular/common/http";
import { Component } from "@angular/core";

@Component({
  selector: "app-tab3",
  templateUrl: "tab3.page.html",
  styleUrls: ["tab3.page.scss"],
})
export class Tab3Page {
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    this.getData();
  }

  res: Result;

  getData() {
    // 我们的服务器采用的是 session 机制, 会自动存储一个 唯一标识 到 cookie 中
    // 而 angular 默认不开启 cookie 的自动存储-- 为了安全
    let url = "/api/data/cart/list.php";

    // withCredentials: 代表携带 cookie 中的 sessionId
    this.http.get(url, { withCredentials: true }).subscribe((res: Result) => {
      console.log(res);

      this.res = res;
    });
  }

  // delta可选值: +1 或 -1
  doUpdate(index, delta) {
    // ES6新增的 解包语法
    let { iid, count } = this.res.data[index];

    let newCount = parseInt(count) + delta;

    let url = `/api/data/cart/update_count.php?iid=${iid}&count=${newCount}`;

    this.http.get(url, { withCredentials: true }).subscribe((res: any) => {
      console.log(res);

      if (res.code == 200) {
        this.res.data[index].count = newCount;
      } else {
        alert("更新失败");
      }
    });
  }
}
//////////////////////////////////////////
interface Result {
  code: number;
  data: Data[];
}

interface Data {
  count: string;
  iid: string;
  lid: string;
  pic: string;
  price: string;
  spec: string;
  title: string;
}

/**
 * 登录状态判定如何实现?
 *
 * 例如购物车: 只有登录状态才能查看, 在发送请求时, 服务器如何判定 当前发请求的 是谁发的.
 *
 * 例子: 吉吉 到银行存了 100万. 当吉吉下次到银行取钱的时候, 银行怎么知道他存了100万?
 * 解决: 银行会发银行卡 给 吉吉, 同时在系统中 存放 此银行卡 对应的相关信息.
 *
 * 这是第一种解决方案: session 方案 -- 属于服务器技术, 前端全程无感知.
 * 1. 访问服务器, 登录成功后, 服务器生成一个 唯一标识, 类似于银行卡号 是一个30多位的字符串.
 * 2. 服务器会记录, 此字符串对应哪个用户 及 相关信息
 * 3. 服务器把此字符串 发给用户浏览器存储.
 * 4. 用户再次访问, 浏览器会自动携带此唯一标识给服务器.
 * 5. 服务器通过唯一标识 查询出对应的用户信息
 *
 * 缺点: 服务器查询记录 非常耗时.
 */

/**
 * token机制 解决登录状态
 * 原因: 服务器为了避免 大量的查询操作. 办法:
 * 1. 用户登录之后, 把用户的相关信息 进行加密, 加密成字符串.  此加密方式只有服务器知道
 * 2. 把这个加密的字符串 发给用户存储
 * 3. 当用户再次访问时, 携带这个加密的字符串(token) 发给服务器
 * 4. 服务器解密 就可以知道 来访用户的信息.   服务器不需要存储和查询操作. 只需要解密即可!
 *
 * 缺点: 不安全 -- csrf攻击
 * token服务器会经常过期
 */
