import { HttpClient } from "@angular/common/http";
import { Component } from "@angular/core";

@Component({
  selector: "app-tab2",
  templateUrl: "tab2.page.html",
  styleUrls: ["tab2.page.scss"],
})
export class Tab2Page {
  constructor(public http: HttpClient) {}

  ngOnInit(): void {
    this.getData();
  }

  res: Result;
  // 多个方法中 复用的 变量, 最好提取成属性
  url = "http://101.96.128.94:9999/data/product/list.php?pno=";

  getData() {
    this.http.get(this.url + 1).subscribe((res: Result) => {
      console.log(res);

      this.res = res;
    });
  }

  doRefresh(event) {
    this.http.get(this.url + 1).subscribe((res: Result) => {
      console.log(res);
      this.res = res;

      event.target.complete(); //结束下拉刷新动画
    });
  }

  loadData(event) {
    let nextPage = this.res.pno + 1;
    this.http.get(this.url + nextPage).subscribe((res: Result) => {
      console.log(res);
      res.data = this.res.data.concat(res.data);

      this.res = res;
      event.target.complete(); //本次加载更多结束.
    });
  }
}

////////////////////////////////////
interface Result {
  data: Data[];
  pageCount: number;
  pageSize: number;
  pno: number;
  recordCount: number;
}

interface Data {
  is_onsale: string;
  lid: string;
  pic: string;
  price: string;
  sold_count: string;
  title: string;
}
