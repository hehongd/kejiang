import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-tab4",
  templateUrl: "./tab4.page.html",
  styleUrls: ["./tab4.page.scss"],
})
export class Tab4Page implements OnInit {
  uname = "";
  upwd = "";

  doLogin() {
    console.log(this.uname, this.upwd);
    /**
     * 请求的类型: 根据服务器的 RESTFul 规则, 请求分为 4 类:
     * 但是由于服务器人员偷懒/不专业: 实际使用的请求方式是两种-- POST 和 GET
     * 1. POST -- 改,增
     * 2. DELETE -- 删
     * 3. PUT -- 改
     * 4. GET -- 查
     */

    /**
     * GET 和 POST的格式区别:
     * 1. GET:  路径和参数在一起  xxxx?xx=xx&xx=xx
     * 2. POST: 路径和参数分开
     */
    let url = "/api/data/user/login.php";
    // 参数分开写
    let params = `uname=${this.uname}&upwd=${this.upwd}`;
    // 服务器接收数据 也分: json格式 还是 xxx=xx&xxx=xx
    // 需要在方法头告诉服务器: 我们的数据是 application/x-www-form-urlencoded
    let options = {
      headers: new HttpHeaders({
        "content-type": "application/x-www-form-urlencoded",
      }),
      // 要求: 开放cookie 的使用权限, 配合服务器的 session 机制实现登录保持
      // 必须解决跨域问题, 证书不允许后台 'Access-Control-Allow-Origin:*' 写法
      withCredentials: true,
    };

    // 正确: doudou 123456
    this.http.post(url, params, options).subscribe((res: any) => {
      console.log(res);
      // res: 默认为 object 类型, 即{},  所以  res.code 会报错
      if (res.code == 200) {
        alert("登录成功");
      } else {
        alert("登录失败");
      }
    });
  }

  constructor(public http: HttpClient) {}

  ngOnInit() {}
}
