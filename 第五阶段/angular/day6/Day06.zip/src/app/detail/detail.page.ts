import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-detail",
  templateUrl: "./detail.page.html",
  styleUrls: ["./detail.page.scss"],
})
export class DetailPage implements OnInit {
  // 模仿vue中: route 和 router
  // route: 操作路由的参数
  // router: 操作路由动作: 跳转操作
  constructor(public http: HttpClient, public route: ActivatedRoute) {}

  ngOnInit() {
    this.getData();
  }

  res: Result;

  getData() {
    let lid = this.route.snapshot.params.lid;
    let url = "http://101.96.128.94:9999/data/product/details.php?lid=" + lid;

    this.http.get(url).subscribe((res: Result) => {
      console.log(res);

      // 为详情的内容 图片添加前缀路径:
      // src="img -> src="http://101.96.128.94:9999/img
      res.details.details = res.details.details.replace(
        /src="img/g, // g : 代表匹配所有符合的
        'src="http://101.96.128.94:9999/img'
      );

      // //img20  -> http://img20
      res.details.details = res.details.details.replace(
        /\/\/img20/g, // g : 代表匹配所有符合的
        "http://img20"
      );

      this.res = res;
    });
  }

  addToCart() {
    let url = "/api/data/cart/add.php?buyCount=1&lid=" + this.res.details.lid;

    this.http.get(url, { withCredentials: true }).subscribe((res: any) => {
      console.log(res);

      if (res.code == 200) {
        alert("添加成功");
      } else {
        alert("添加失败");
      }
    });
  }
}

///////////////////////////////////////

interface Result {
  details: Details;
  // UI中未使用此数据, 可以不声明
  family: any;
}

interface Details {
  category: string;
  cpu: string;
  details: string;
  disk: string;
  family_id: string;
  is_onsale: string;
  lid: string;
  lname: string;
  memory: string;
  os: string;
  picList: PicList[];
  price: string;
  promise: string;
  resolution: string;
  shelf_time: string;
  sold_count: string;
  spec: string;
  subtitle: string;
  title: string;
  video_card: string;
  video_memory: string;
}

interface PicList {
  laptop_id: string;
  lg: string;
  md: string;
  pid: string;
  sm: string;
}
