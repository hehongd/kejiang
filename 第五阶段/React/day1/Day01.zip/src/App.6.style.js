// 动态样式
/**
 * vue中: :style="{样式名:值, 样式名:值}"  :class="{样式类: true/false}"
 *
 * ng 中: [ngStyle]="{样式名:值, 样式名:值}"  [ngClass]="{样式类: true/false}"
 */

//rcc
import React, { Component } from "react";

export default class App extends Component {
  state = { size: 18, br: 0, title: "变圆" };

  _big() {
    this.setState({ size: this.state.size + 1 });
  }

  _radius = () => {
    if (this.state.br === 50) {
      // 还原
      this.setState({ br: 0, title: "变圆" });
    } else {
      this.setState({ br: this.state.br + 10 }, () => {
        //回调:更新完毕后
        if (this.state.br === 50) {
          this.setState({ title: "还原" });
        }
      });
    }
  };

  render() {
    return (
      <div>
        <button onClick={this._big.bind(this)}>变大</button>
        {/* style必须是对象类型  */}
        <div style={{ color: "red", fontSize: this.state.size + "px" }}>
          Hello World!
        </div>

        <button onClick={this._radius}>{this.state.title}</button>
        <div
          style={{
            backgroundColor: "green",
            width: "100px",
            height: "100px",
            borderRadius: this.state.br + "px",
          }}
        ></div>
      </div>
    );
  }
}
