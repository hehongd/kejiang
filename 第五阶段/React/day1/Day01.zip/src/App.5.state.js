// setState 的异步性

//rcc
import React, { Component } from "react";

export default class App extends Component {
  state = { num: 1 };

  _change = () => {
    // a++ 和 ++a:
    // 按照从左向右读: 先读到哪个用哪个.  a++ 先用a; ++a 先加

    // 假设 num=1； 此时a就是 {num:1}   this.state.num 是2
    let a = { num: this.state.num++ };

    // setState(): 需要刷新UI, 刷新UI属于耗时操作->cpu 和 gpu
    // 防止阻塞线程: 官方设计到异步执行.  每个线程能做一件事.  cpu的12线程就是 能同时做12件事
    // 参数2: 回调函数, 在页面刷新完毕后执行
    this.setState(a, () => {
      console.log("UI更新完毕, num变为:", this.state.num);
    }); // {num:1}

    console.log(this.state.num);

    // 在vue中, 有没有同样的方式, 能够监听到DOM 刷新结束的时机??
    // $nextTick() -- 详见 FTP 的 99 面试题
  };

  render() {
    return (
      <div>
        <button onClick={this._change}>{this.state.num}</button>
      </div>
    );
  }
}
