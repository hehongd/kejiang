// 外部 css 样式的写法

/**
 * css样式有3种写法:
 * 1. 内联样式: style
 * 2. 内部样式: html的head种, <style></style>
 * 3. 外部样式: .css文件, 然后引入到代码中
 */

// rcc
import React, { Component } from "react";

/**
 * 引入外部的css文件:
 * 1. html 引入: <link rel="stylesheet" href="style.css">
 * 2. css 引入: @import '路径.css';
 * 3. js 引入: import 'css文件路径'
 */

// 最常见的报错: import 'xxx.css'
// import 可以引入模块 或 文件
// 系统会根据 引号里的 是文件路径, 才会当做文件引入; 否则会当成模块引入
// ./ / ../ :这些都是文件路径特有的标识.  要求必须添加这些标识
import "./App.css";

export default class App extends Component {
  render() {
    return (
      <div>
        {/* JSX语法并不是html. 本质上是 DOM 操作的语法糖写法.  而DOM操作中的 就是className */}
        <div className="danger">吉吉国王</div>
        {/* 没有vue那种 @class="{xxx: true}" 写法 */}
      </div>
    );
  }
}
