// 双向数据绑定

/**
 * vue 和 react 的差异:
 * * vue 是 单向数据流
 * * react 是 双向数据流
 *
 * vue中: <input :value="uname" />   uname变化, 输入框的值会变吗? -- 不会变, 晚上自己试
 *
 * react中: <input value={this.state.uname} />  输入框的值会变
 */

//rcc
import React, { Component } from "react";

export default class App extends Component {
  state = { uname: "dongdong" };

  render() {
    return (
      <div>
        {/* react 不存在 v-model 这种简化写法.  必须手写 双向绑定的过程 */}
        <input type="text" value={this.state.uname} onChange={this._change} />

        <br />
        <input
          type="text"
          value={this.state.uname}
          onChange={(event) => this.setState({ uname: event.target.value })}
        />

        <p>{this.state.uname}</p>
      </div>
    );
  }

  // 事件触发的函数, 事件会作为参数传入.
  _change = (event) => {
    // console.log(event);
    console.log(event.target.value);

    // 更新到数据中
    this.setState({ uname: event.target.value });
  };
}
