// 事件传参

// rcc
import React, { Component } from "react";

export default class App extends Component {
  show(name) {
    alert(name);
  }

  // 箭头函数能替换this么?    答案: 不能
  show1 = (name) => {
    alert(name, this.name);
  };

  render() {
    return (
      <div>
        {/* bind: 执行后, 返回一个新的函数, 其中的参数都已经指定. 只待执行 */}
        <button onClick={this.show.bind(this, "东东")}>东东</button>
        {/* 点击时, 执行箭头函数, 箭头函数再执行其中的show */}
        <button onClick={() => this.show("亮亮")}>亮亮</button>
        {/* 箭头函数只有一种方案: 箭头 套 */}
        <button onClick={() => this.show1("然然")}>然然</button>
      </div>
    );
  }
}
