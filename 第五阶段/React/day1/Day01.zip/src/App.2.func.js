// 事件中的 this 指向问题

/**
 * 函数分两种:
 * 普通函数: function(){}
 *    * this指向 函数调用者.   xxx.show(); show()中的this 指向xxx
 *    * 3个与this有关的方式 bind apply call
 *    ** xxx.bind(this):  只改指向 但不会执行
 *    ** apply, call: 修改指向的同时 会执行.  两者的差异是 参数2不同
 * 箭头函数: ()=>{}
 *    * this指向 声明时所在环境 的this
 *
 *
 */

// rcc
import React, { Component } from "react";

export default class App extends Component {
  name = "东东";

  /**
   * 普通的函数的this指向调用者.   obj.show();  obj就是this
   * window 触发的函数, this是 undefined
   */
  show() {
    console.log(this.name);
  }

  // 实际工作: 更加偏爱 箭头函数.  杜绝this的指向问题
  show1 = () => {
    console.log(this.name);
  };

  render() {
    return (
      <div>
        <button onClick={this.show1}>箭头函数</button>

        {/* 相当于: 点击按钮之后 打然然的媳妇 */}
        {/* 点击后 执行 当前对象的show方法:  事件由window触发! */}
        {/* bind: 替换 普通函数的 this 指向 */}
        <button onClick={this.show.bind(this)}>普通函数</button>

        {/* 利用箭头函数, 也可以保持this指向 */}
        <button onClick={() => this.show()}>箭头+普通</button>

        {/* 箭头函数的格式: ()=>{ xxx }  如果 {} 只有一行代码, 语法糖: ()=> xxx */}
        {/* 点击之后, 执行的是箭头函数, 而 箭头函数 再执行其中的 show() 方法 */}
        <button
          onClick={() => {
            this.show();
          }}
        >
          箭头+普通
        </button>
      </div>
    );
  }
}
