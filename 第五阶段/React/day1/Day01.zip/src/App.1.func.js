// index.html => index.js => App.js
// React属于 单页应用 SPA项目

// 快捷代码块 rcc
import React, { Component } from "react";

export default class App extends Component {
  render() {
    return (
      <div>
        <h1>Hello World!</h1>
        {/* 
        vue中: @click=""  v-on:click=""
        ng中: (click)=""
        原生: onclick=""
        小程序: bindtap="" 或 catchtap=""
        react: onClick=""
        */}

        {/* {}中的代码在 页面显示时, 会自动执行 */}
        <button onClick={this.show}>点我</button>
        {/* 
        关于事件中的方法名是否写()结尾
        不带参数时:
        vue: 都可以  @click="show"  @click="show()"
        angular: 必须带()  (click)="show()"
        react: 不带()  onClick={this.show}
        */}
      </div>
    );
  }

  show() {
    alert("点击事件");
  }
}
