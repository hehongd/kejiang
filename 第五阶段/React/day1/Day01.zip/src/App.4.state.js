// 状态值 State

/**
 * 请描述 react 和 vue 的差异:  为什么大型项目不适合vue?
 *
 * 数据绑定的差异:
 * -- vue 依赖为每个数据项增加 set 和 get 方法. 通过方法来监听数据的变化 并 刷新DOM
 *    大型项目 数据量很大,  假设50 变量 就要额外新增 100个方法.  性能会降低
 *
 * -- react 和 小程序相同: 通过 setState/setData 来更新数据. 不需要实时监听每个变量的变更, 性能更高.
 */

//rcc
import React, { Component } from "react";

export default class App extends Component {
  // 小程序中有一个特殊的属性: data,  需要配合 setData() 进行更新操作, 才能刷新到页面上.
  // react中 是  state 属性 和 setState 属性配合
  state = { num: 1 };

  count = 100;

  // 习惯: 事件触发的函数 带有 _ 前缀
  _change() {
    // //后台会爆黄: state中的值不应该直接修改, 应该使用 setState 修改
    this.state.num++;

    this.setState({ num: this.state.num + 1 });

    // setState() 有两个作用
    // 1. 更新数据
    // 2. 更新UI -- 不限于state中的数据项. 例如 count 也会变化
  }

  render() {
    return (
      <div>
        <button onClick={this._change.bind(this)}>{this.state.num}</button>
        {/* react 每个属性, 没有监听. 不会因为修改而自动变化 */}
        <button onClick={() => this.count++}>{this.count}</button>
      </div>
    );
  }
}
